import * as React from 'react';
import { useEffect, useState } from 'react';
import './assets/css/style.css';

import Sidebar from '../../../../components/Sidebar/index';

import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import MainBody from '../../../../components/MainBody/index';
import EditIntegration from '../../../../components/Popup/Edit/EditIntegration';
import Addpopup from '../Add/index';

import logo from './assets/img/logo.svg';
import axios from 'axios';
import { map } from 'lodash';

const breadcrumbs_data = ['Dashboard', 'Integrations'];
const current_tab = ['Integrations'];

const Layout = () => {
  const [Integationdata, setIntegrationdata] = useState([]);
  //var Integrationdata = [];
  var demo = ['1', '2', '3', '4'];
  const addItem = true;
  const EditItem = true;

  function get_integrations() {
    axios.get('http://localhost:3344/integration/integrationdata').then(res => {
      //Integrationdata = res.data;
      setIntegrationdata(res.data);
      //   Integrationdata.flat();
      //console.log(Integrationdata);
    });
  }

  //   useEffect(() => {
  //     axios.get('http://localhost:3344/integration/integrationdata').then(res => {
  //       Integrationdata = res.data;
  //       //   Integrationdata.flat();
  //       console.log(Integrationdata);
  //     });
  //   });

  return (
    <>
      <div className="layout">
        <Grid container>
          <Grid item xs={2}>
            <div className="sidebar-div">
              <Sidebar current_tab={current_tab} />
            </div>
          </Grid>
          <Grid item xs={10}>
            <div className="body">
              <div className="body_top_bar">
                <MainBody
                  heading="Integrations"
                  breadcrumbs={breadcrumbs_data}
                />
              </div>
              <div className="body_content">
                <Grid
                  container
                  direction="row"
                  justifyContent="space-between"
                  alignItems="center"
                >
                  <h1>Integrations</h1>
                  <Addpopup btnname="add" heading="Select type" />
                </Grid>
                <Box mt={2}>
                  {Integationdata.map((item, i) => (
                    <li className="travelcompany-input" key={i}>
                      <span className="input-label">{item.user}</span>
                    </li>

                    //   <Paper className="integration_list">
                    //     <Grid container>
                    //       <Grid
                    //         item
                    //         xs={11}
                    //         container
                    //         direction="row"
                    //         justifyContent="flex-start"
                    //         alignItems="center"
                    //         className="integration_list_name"
                    //       >
                    //         <img
                    //           src={logo}
                    //           alt="Integration"
                    //           className="integration_list_img"
                    //         />
                    //         <span> {item.user} </span>
                    //       </Grid>
                    //       <Grid
                    //         items
                    //         xs={1}
                    //         container
                    //         direction="row"
                    //         justifyContent="center"
                    //         alignItems="center"
                    //       >
                    //         <EditIntegration
                    //           btnname="edit"
                    //           heading="Edit Integration"
                    //         />
                    //       </Grid>
                    //     </Grid>
                    //   </Paper>
                  ))}
                </Box>
              </div>
            </div>
          </Grid>
        </Grid>
      </div>
    </>
  );
};

export default Layout;
