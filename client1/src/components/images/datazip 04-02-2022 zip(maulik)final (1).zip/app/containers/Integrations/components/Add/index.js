import * as React from 'react';
import { useState } from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import Paper from '@mui/material/Paper';
import closeicon from '../../../../images/closeicon.svg';
import five9icon from '../../../../images/five9.svg';
import logoipsum from '../../../../images/logoipsum.svg';
import loginipsum1 from '../../../../images/logoipsum1.svg';
import loginipsum2 from '../../../../images/logoipsum2.svg';
import EditIntegration from '../../../../components/Popup/Edit/EditIntegration';
import SelectType from '../../../../components/Popup/SelectType/index';
import { Grid } from '@mui/material';

import './assets/style.css';
import axios from 'axios';

export default function inxex(props) {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  return (
    <div>
      <Button size="large" variant="contained" onClick={handleOpen}>
        {props.btnname}
      </Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box className="add-popup-main-box">
          <div className="sync-popup">
            <div className="sync-popup-inner">
              <div
                className="select-typt-popup-header"
                style={{
                  height: '60px !important',
                  borderRadius: '0px !important',
                }}
              >
                <div className="select-popup-close">
                  <a onClick={handleClose}>
                    <img
                      src={closeicon}
                      style={{
                        marginRight: '40px !important',
                        paddingBottom: '30px',
                      }}
                    />
                  </a>
                </div>
              </div>
              <div className="select-type-heading">
                <h1>{props.heading}</h1>
                <h2 style={{ color: 'rgb(80,80,80' }}>{props.heading2}</h2>
              </div>
              <div className="select-type-integartion-body">
                <Box>
                  <div style={{ marginBotto: '30px !important' }}>
                    <Paper className="select-type-integration">
                      <SelectType heading="Connect Five9" />
                      {/* <EditIntegration btnname="add" heading="Connect Five9" dataimg="0" /> */}
                    </Paper>
                    <Paper className="select-type-integration">
                      <img src={logoipsum} />
                    </Paper>
                    <Paper className="select-type-integration">
                      <img src={loginipsum1} />
                    </Paper>
                    <Paper
                      className="select-type-integration"
                      style={{ marginBottom: '40px !important' }}
                    >
                      <img src={loginipsum2} />
                    </Paper>
                  </div>
                </Box>
              </div>
            </div>
          </div>
        </Box>
      </Modal>
    </div>
  );
}
