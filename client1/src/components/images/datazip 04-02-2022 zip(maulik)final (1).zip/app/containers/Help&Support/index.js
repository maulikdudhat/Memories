import React from 'react'
import Popup from'../../components/Popup/index'
import './assets/style.css'
import { useState } from 'react'

const index = () => {

    const[buttonPopup, setButtonPopup] =useState(false)
    return (
        <div className='help-support'>
            <Popup trigger={buttonPopup} setTrigger={setButtonPopup}/>
        </div>
    )
}

export default index
