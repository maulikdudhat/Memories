import * as React from 'react';
import Layout from './components/layout/layout';

export default function settings() {
    return (
        <>
            <Layout />
        </>
    );
};
