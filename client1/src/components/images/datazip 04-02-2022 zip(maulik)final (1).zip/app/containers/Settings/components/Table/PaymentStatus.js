import React from 'react'

const paymentStatus = {
    "paid": "green",
    "unpaid": "red"
  
  }

function PaymentStatus() {
    return (
        <div>
            
        </div>
    )
}

export default PaymentStatus
