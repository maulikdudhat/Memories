import React from 'react'
import './table.css'
import PaymentStatus from './PaymentStatus'

const  Table = (props) =>{

    const Invoices = {
        head: [
          "Invoice No",
          "name",
          "Payment Status",
          "Payment Amount"
        ],
        body: [
          {
            "id": "(123)456 - 7890",
            "user": "lorem Ipusum",
            "status": 'paid',
            "amount": '$212546'
      
          },
          {
            "id": "(123)456 - 7890",
            "user": "lorem Ipusum",
            "status": 'pending',
            "amount": '$212546'
      
          },
          {
            "id": "(123)456 - 7890",
            "user": "lorem Ipusum",
            "status": 'paid',
            "amount": '$212546'
      
          },
          {
            "id": "(123)456 - 7890",
            "user": "lorem Ipusum",
            "status": 'paid',
            "amount": '$212546'
      
          },
      
        ]
      }
      
      const renderInvoicHead = (item, index) => (
        <th key={index}>{item}</th>
      )
      const renderInvoiceBody = (item, index) => (
        <tr key={index}>
          <td>{item.id}</td>
          <td>{item.user}</td>
          <td style={{
            color:((item.status === 'paid' && 'green')|| (item.status === 'pending' && 'red'))
          }}>{item.status}</td>
          <td>{item.amount}</td>
        </tr>
      )

  
    return (
        <div>
            <div className='table-wrapper'>
                <table className='invoicea-col-itmes'>
                    {
                        Invoices.head && renderInvoicHead ? (
                            <thead >

                                {
                                    Invoices.head.map((item, index) => renderInvoicHead(item, index))
                                }


                            </thead>
                        ) : null
                    }
                    
                    {
                        Invoices.body && renderInvoiceBody ? (
                            <tbody>
                                {
                                    Invoices.body.map((item, index) =>renderInvoiceBody(item, index))
                                }
                            </tbody>
                        ) : null
                    }
                </table>
            </div>
        </div>
    )
}

export default Table
