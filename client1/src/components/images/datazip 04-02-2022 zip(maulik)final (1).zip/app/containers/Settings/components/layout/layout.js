import React, { useState } from 'react';

import './assets/css/style.css';

import Sidebar from '../../../../components/Sidebar/index';

import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';

import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';

import MainBody from '../../../../components/MainBody/index';

import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';

import TextField from '@mui/material/TextField';
import { InputAdornment } from '@mui/material';
import EmailAddressIcon from '../../../../../app/containers/LoginPage/assets/img/EmailAddressIcon.svg';
import usericon from '../../../../../app/images/nameicon.svg';
import PassWordIcon from '../../../../../app/containers/LoginPage/assets/img/PassWordIcon.svg';
import Link from '@mui/material/Link';
import { grid } from '@mui/system';
import nameicon from '../../../../../app/images/nameicon.svg';

import TableInvoice from '../Table/Table'

// popup resource import here

import Modal from '@mui/material/Modal';
import TextareaAutosize from '@mui/material/TextareaAutosize';
import Editicon from '../../../Help&Support/img/editicon.svg';
import closeicon from '../../../../images/closeicon.svg';
import backicon from '../../../../images/backicon.svg';
import invitebtn from '../../../../images/invitebtn.svg';
import phoneicon from '../../../../images/phoneicon.svg';
import browsericon from '../../../../images/browsericon.svg';
import EditProfile from '../../../../../app/components/Sidebar/Editprofile/index'
import Dropzone from '../../../../../app/components/Dropzon/DropZone';

import edtediticoncard from '../../../../images/editiconcard.svg';
import deleteicon from '../../../../images/deleteicon.svg';


const style = {
  position: 'absolute',
  top: '0',
  left: 'auto',
  right: '0',
  justifyContent:'flex-end',
  display: 'flex',
  // transform: 'translate(-50%, -50%)',
};
const paymentstyle = {
  paid: 'red',
  unpaid: 'green',

}

const breadcrumbs_data = ['Dashboard', 'Settings'];

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 16,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  // '&:nth-of-type(odd)': {
  //   backgroundColor: theme.palette.action.hover,
  // },
  // hide last border
  '&:last-child td': {
    border: 1,
  },
  td: {
    backgroundColor: 'rgba(47, 128, 237, 0.1)',
  },
}));

function createData(name, calories, fat, carbs, protein, payment) {
  return { name, calories, fat, carbs, protein, payment };
}


const rows = [
  createData('Frozen yoghurt', 159, 6.0, 24, 4.0, 'paid'),
  createData('Ice cream sandwich', 237, 9.0, 37, 4.3, 'unpaid'),
  createData('Eclair', 262, 16.0, 24, 6.0, 'paid'),
  createData('Cupcake', 305, 3.7, 67, 4.3, 'paid'),
  createData('Gingerbread', 356, 16.0, 49, 3.9, 'paid'),
];
const Invoices = {
  head: [
    "Invoice No",
    "name",
    "Payment Status",
    "Payment Amount"
  ],
  body: [
    {
      "id": "(123)456 - 7890",
      "user": "lorem Ipusum",
      "status": 'paid',
      "amount": '$212546'

    },
    {
      "id": "(123)456 - 7890",
      "user": "lorem Ipusum",
      "status": 'paid',
      "amount": '$212546'

    },
    {
      "id": "(123)456 - 7890",
      "user": "lorem Ipusum",
      "status": 'paid',
      "amount": '$212546'

    },
    {
      "id": "(123)456 - 7890",
      "user": "lorem Ipusum",
      "status": 'paid',
      "amount": '$212546'

    },

  ]
}

const paymentStatus = {
  "paid": "success",
  "unpaid": "danger"

}

const renderInvoicHead = (item, index) => (
  <th key={index}>{item}</th>
)

const renderInvoiceBody = (item, index) => (
  <tr key={index}>
    <td>{item.id}</td>
    <td>{item.user}</td>
    <td>{item.status}</td>
    <td>{item.amount}</td>
  </tr>
)
const Layout = () => {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  return (
    <>
      <div className="layout">
        <Grid container>
          <Grid item xs={2}>
            <div className="sidebar-div">
              <Sidebar />
            </div>
          </Grid>
          <Grid item xs={10}>
            <div className="body">
              <div className="body_top_bar">
                <MainBody heading="Settings" breadcrumbs={breadcrumbs_data} />
              </div>
              <div className="body_content">
                <div className="invited-users">
                  <Box className="invited-users-box">
                    <Paper className="invited-users-paper">
                      <Grid
                        container
                        direction="row"
                        justifyContent="space-between"
                        alignItems="center"
                      >
                        <h2 className="invited-users-header">Users</h2>
                        
                        <Button
                          variant="contained"
                          className="btn invited-users-button"
                          onClick={handleOpen}
                        >
                          Invite
                        </Button>
                        <Modal
                          open={open}
                          onClose={handleClose}
                          aria-labelledby="modal-modal-title"
                          aria-describedby="modal-modal-description"
                        >
                          <Box sx={style}>
                            <div className="invite">
                              <div className="invite-inner">
                                <div className="invite-header">
                                  <div>
                                    <h3>Invite</h3>
                                  </div>

                                  <div className="invite-close">
                                    
                                
                                  
                                    <a onClick={handleClose}>
                                      <img src={closeicon} />
                                    </a>
                                  </div>
                                </div>
                                <Box>
                                    <Grid
                                      container
                                      direction="row"
                                      justifyContent="space-between"
                                      alignItems="center"
                                      spacing={2}
                                      style={{paddingTop: '30px',paddingRight:'40px', paddingLeft:'30px'   }}
                                    >
                                      <Grid item xs={12}>
                                        <TextField
                                          className="email-text-field"
                                          margin="normal"
                                          required
                                          fullWidth
                                          id="input-with-icon-textfield"
                                          name="emailaddress"
                                          placeholder="Name"
                                          InputProps={{
                                            startAdornment: (
                                              <InputAdornment position="start">
                                                <img
                                                  src={usericon}
                                                  alt="Email Address"
                                                />
                                              </InputAdornment>
                                            ),
                                          }}
                                        />
                                      </Grid>
                                      <Grid item xs={12} >
                                        <TextField
                                          className="email-text-field"
                                          margin="normal"
                                          required
                                          fullWidth
                                          id="input-with-icon-textfield"
                                          name="emailaddress"
                                          placeholder="Email Address"
                                          InputProps={{
                                            startAdornment: (
                                              <InputAdornment position="start">
                                                <img
                                                  src={EmailAddressIcon}
                                                  alt="Email Address"
                                                />
                                              </InputAdornment>
                                            ),
                                          }}
                                        />
                                      </Grid>
                                    </Grid>
                                  
                                </Box>
                                <div className="invite-footer">
                                  
                                  <Button varient="outline" style={{background:'white',margin:'35px', width:'126px' }}>INvite</Button>
                                </div>
                              </div>
                            </div>
                          </Box>
                        </Modal>
                      </Grid>
                      <Grid
                        container
                        direction="row"
                        justifyContent="space-between"
                        alignItems="center"
                        spacing={2}
                        marginTop={1}
                        
                      >
                        <Grid item xs={2} >
                          <Card className="user-profile-card">
                            <CardContent className="user-profile-content">
                              <div className="user-profile-edit-delete-icon" >
                                <EditProfile btnname="editbtn" className="card-edit-btn" />
                                <a style={{ cursor: 'pointer' }}><img src={deleteicon} /></a>
                              </div>
                              <Stack direction="row" justifyContent={'center'}>
                                <Avatar
                                  alt="Remy Sharp"
                                  src="https://i.pravatar.cc/300"
                                  sx={{ width: 70, height: 70 }}
                                />
                              </Stack>
                              <p className="user-profile-name">David Smith</p>
                              <p className="user-profile-bio">Lorem ipsum</p>
                            </CardContent>
                          </Card>
                        </Grid>

                        <Grid item xs={2}  >
                          <Card className="user-profile-card">
                            <CardContent className="user-profile-content">
                              <div className="user-profile-edit-delete-icon">
                                <a style={{ cursor: 'pointer' }}><img src={edtediticoncard} /></a>
                                <a style={{ cursor: 'pointer' }}><img src={deleteicon} /></a>
                              </div>
                              <Stack direction="row" justifyContent={'center'}>
                                <Avatar
                                  alt="Remy Sharp"
                                  src="https://i.pravatar.cc/300"
                                  sx={{ width: 70, height: 70 }}
                                />
                              </Stack>
                              <p className="user-profile-name">David Smith</p>
                              <p className="user-profile-bio">Lorem ipsum</p>
                            </CardContent>
                          </Card>
                        </Grid>

                        <Grid item xs={2} >
                          <Card className="user-profile-card">
                            <CardContent className="user-profile-content">
                              <div className="user-profile-edit-delete-icon">
                                <a style={{ cursor: 'pointer' }}><img src={edtediticoncard} /></a>
                                <a style={{ cursor: 'pointer' }}><img src={deleteicon} /></a>
                              </div>
                              <Stack direction="row" justifyContent={'center'}>
                                <Avatar
                                  alt="Remy Sharp"
                                  src="https://i.pravatar.cc/300"
                                  sx={{ width: 70, height: 70 }}
                                />
                              </Stack>
                              <p className="user-profile-name">David Smith</p>
                              <p className="user-profile-bio">Lorem ipsum</p>
                            </CardContent>
                          </Card>
                        </Grid>

                        <Grid item xs={2} >
                          <Card className="user-profile-card">
                            <CardContent className="user-profile-content">
                              <div className="user-profile-edit-delete-icon">
                                <a style={{ cursor: 'pointer' }}><img src={edtediticoncard} /></a>
                                <a style={{ cursor: 'pointer' }}><img src={deleteicon} /></a>
                              </div>
                              <Stack direction="row" justifyContent={'center'}>
                                <Avatar
                                  alt="Remy Sharp"
                                  src="https://i.pravatar.cc/300"
                                  sx={{ width: 70, height: 70 }}
                                />
                              </Stack>
                              <p className="user-profile-name">David Smith</p>
                              <p className="user-profile-bio">Lorem ipsum</p>
                            </CardContent>
                          </Card>
                        </Grid>

                        <Grid item xs={2}  >
                          <Card className="user-profile-card">
                            <CardContent className="user-profile-content">
                              <div className="user-profile-edit-delete-icon">
                                <a style={{ cursor: 'pointer' }}><img src={edtediticoncard} /></a>
                                <a style={{ cursor: 'pointer' }}><img src={deleteicon} /></a>
                              </div>
                              <Stack direction="row" justifyContent={'center'}>
                                <Avatar
                                  alt="Remy Sharp"
                                  src="https://i.pravatar.cc/300"
                                  sx={{ width: 70, height: 70 }}
                                />
                              </Stack>
                              <p className="user-profile-name">David Smith</p>
                              <p className="user-profile-bio">Lorem ipsum</p>
                            </CardContent>
                          </Card>
                        </Grid>

                        <Grid item xs={2} >
                          <Card className="user-profile-card">
                            <CardContent className="user-profile-content">
                              <div className="user-profile-edit-delete-icon">
                                <a style={{ cursor: 'pointer' }}><img src={edtediticoncard} /></a>
                                <a style={{ cursor: 'pointer' }}><img src={deleteicon} /></a>
                              </div>
                              <Stack direction="row" justifyContent={'center'}>
                                <Avatar
                                  alt="Remy Sharp"
                                  src="https://i.pravatar.cc/300"
                                  sx={{ width: 70, height: 70 }}
                                />
                              </Stack>
                              <p className="user-profile-name">David Smith</p>
                              <p className="user-profile-bio">Lorem ipsum</p>
                            </CardContent>
                          </Card>
                        </Grid>
                      </Grid>
                    </Paper>
                  </Box>
                </div>

                <div className="invoices">
                  <h2 className="invited-header">Invoices</h2>
                  <TableInvoice

                    headData={Invoices.head}
                    renderHead={(item, index) => renderInvoicHead((item, index))}
                    bodyData={Invoices.body}
                    renderBody={(item, index) => renderInvoiceBody((item, index))}
                  />
                </div>

                <div className="company-profile-section">
                  <Box>
                    <Paper className="company-profile-paper">
                      <Grid
                        container
                       
                        spacing={2}
                      >
                        <Grid item xs={12}>
                          <h2 className="companyprofile">Company Profile</h2>
                        </Grid>
                        <Grid item xs={6}>
                          <TextField
                            className="email-text-field"
                            margin="normal"
                            required
                            fullWidth
                            id="input-with-icon-textfield"
                            name="emailaddress"
                            placeholder="Name"
                            InputProps={{
                              startAdornment: (
                                <InputAdornment position="start">
                                  <img
                                    src={nameicon}
                                    alt="Email Address"
                                    style={{ filter: 'drop-shadow(0px 4px 4px rgba(0, 0, 0, 0.25))' }}
                                  />
                                </InputAdornment>
                              ),
                            }}
                          />
                        </Grid>
                        <Grid item xs={6}>
                          <TextField
                            className="email-text-field"
                            margin="normal"
                            required
                            fullWidth
                            id="input-with-icon-textfield"
                            name="emailaddress"
                            placeholder="Email Address"
                            InputProps={{
                              startAdornment: (
                                <InputAdornment position="start">
                                  <img
                                    src={EmailAddressIcon}
                                    alt="Email Address"
                                    style={{ filter: 'drop-shadow(0px 4px 4px rgba(0, 0, 0, 0.25))' }}

                                  />
                                </InputAdornment>
                              ),
                            }}
                          />
                        </Grid>
                        <Grid item xs={6}>
                          <TextField
                            className="email-text-field"
                            margin="normal"
                            required
                            fullWidth
                            id="input-with-icon-textfield"
                            name="phone"
                            placeholder="Phone"
                            InputProps={{
                              startAdornment: (
                                <InputAdornment position="start">
                                  <img
                                    src={phoneicon}
                                    alt="Email Address"
                                    style={{ filter: 'drop-shadow(0px 4px 4px rgba(0, 0, 0, 0.25))' }}

                                  />
                                </InputAdornment>
                              ),
                            }}
                          />
                        </Grid>
                        <Grid item xs={6}>
                          <TextField
                            className="email-text-field"
                            margin="normal"
                            required
                            fullWidth
                            id="input-with-icon-textfield"
                            name="website"
                            placeholder="Website"
                            InputProps={{
                              startAdornment: (
                                <InputAdornment position="start">
                                  <img
                                    src={browsericon}
                                    alt="Website"
                                    style={{ filter: 'drop-shadow(0px 4px 4px rgba(0, 0, 0, 0.25))' }}

                                  />
                                </InputAdornment>
                              ),
                            }}
                          />
                        </Grid>

                        <Grid item xs={6} className="column-text-button">
                         
                          <Dropzone/>
                        </Grid>
                        <Grid item xs={6} className="column-text-button" >
                          <Button
                            className="login-btn-text-field"
                            type="submit"
                            variant="contained"
                          >
                            Save
                          </Button>
                        </Grid>
                      </Grid>
                    </Paper>
                  </Box>
                </div>
              </div>
            </div>
          </Grid>
        </Grid>
      </div>
    </>
  );
};

export default Layout;


