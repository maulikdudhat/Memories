/**
 *
 * App
 *
 * This component is the skeleton around the actual pages, and should only
 * contain code that should be seen on all pages. (e.g. navigation bar)
 */

import React, { useEffect, useState, useContext } from 'react';
import { Helmet } from 'react-helmet';
import styled from 'styled-components';
import { Switch, Route, Redirect } from 'react-router-dom';

import LoginPage from 'containers/LoginPage/Loadable';
import Dashboard from 'containers/Dashboard/Loadable';
import Integrations from 'containers/Integrations/Loadable';
import Numbers from 'containers/Numbers/Loadable';
import Settings from 'containers/Settings/Loadable';
import ForgotPassword from 'containers/ForgotPasswordPage/Loadable';
import NotFoundPage from 'containers/NotFoundPage/Loadable';
import Header from 'components/Header';
import Footer from 'components/Footer';
import jwt from 'jsonwebtoken';
import configureStore from '../../configureStore';
import GlobalStyle from '../../global-styles';
import { useDispatch } from 'react-redux';
import NoteState from '../../context/NoteState';
import noteContext from '../../context/noteContext';

const AppWrapper = styled.div`
  margin: 0 auto;
  display: flex;
  min-height: 100%;
  padding: 0;
  flex-direction: column;
`;

const secret = process.env.ACCESS_TOKEN_SECRET;

export default function App(props) {
  const loginhandle = useContext(noteContext);
  const [loginflag, setLoginFlag] = useState(false);
  if (localStorage.jwtToken) {
    jwt.verify(localStorage.jwtToken, secret, (err, decode) => {
      if (err) {
      } else {
        dispatch(logout());
      }
    });
  }

  return (
    <NoteState>
      <AppWrapper>
        <Helmet titleTemplate="%s - | Page" defaultTitle="">
          <meta name="description" content="StetsOnWood" />
        </Helmet>
        <Header />
        <Switch>
          <Route exact path="/" component={LoginPage} />
          <Route exact path="/dashboard" component={Dashboard} />
          <Route exact path="/forgotpassword" component={ForgotPassword} />
          <Route exact path="/integrations" component={Integrations} />
          <Route exact path="/numbers" component={Numbers} />
          <Route exact path="/settings" component={Settings} />
          {/* <Route exact path="/help&support" component={HelpSupport} /> */}
          <Route path="" component={NotFoundPage} />
        </Switch>
        <GlobalStyle />
        <Footer />
      </AppWrapper>
    </NoteState>
  );
}
