import React, { useState } from 'react';
import './assets/css/style.css';

import Sidebar from '../../../../components/Sidebar/index';

import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';

import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';

import MainBody from '../../../../components/MainBody/index';

import logo from './assets/img/logo.svg';

import Divider from '@mui/material/Divider';
import Modal from '@mui/material/Modal';
import closeicon from '../../../../images/closeicon.svg';
import Editicon from '../../../../images/closeicon.svg';
import TextareaAutosize from '@mui/material/TextareaAutosize';
import { InputAdornment } from '@mui/material';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Popup from '../../../../components/Popup/index';
import Sync from '../../../../components/Popup/Sync/Sync'
import Edit from '../../../../components/Popup/Edit/Edit'

import NewDNIGroup from '../../../../components/Popup/NewDniGroup/NewDNIGroup';

/** Icons */

import FileCopyIcon from '@mui/icons-material/FileCopy';
import CodeIcon from '@mui/icons-material/Code';
import shareicon from '../../../../images/shareicon.svg';

const breadcrumbs_data = ['Dashboard', 'Numbers'];

const style = {};

const Layout = () => {
  // popup variables
  const [show, setShow] = useState(false);
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  // integration vriables

  const select_data = [
    {
      value: 1,
      text: 'Up Arrow',
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="40"
          height="40"
          viewBox="0 0 40 40"
          fill="none"
        >
          <script xmlns="" />
          <rect width="40" height="40" rx="5" fill="#DCDCDC" />
          <path
            d="M24.1965 27.9998C23.345 28.0098 22.5378 27.6155 22.0152 26.9341C21.4925 26.2527 21.3145 25.3628 21.5341 24.5289L16.6074 21.6754C15.7561 22.4658 14.5083 22.633 13.4834 22.0942C12.4586 21.5553 11.8751 20.425 12.0226 19.2646C12.1702 18.1042 13.0174 17.1607 14.1436 16.9027C15.2697 16.6447 16.435 17.1271 17.0608 18.1104L21.5333 15.5192C21.4755 15.2976 21.4448 15.0697 21.442 14.8405C21.4307 13.506 22.3454 12.3467 23.6324 12.0641C24.9195 11.7816 26.2256 12.4533 26.7603 13.6728C27.2951 14.8924 26.9117 16.3249 25.8421 17.1035C24.7726 17.8821 23.3106 17.793 22.3408 16.8902L17.4999 19.6935C17.4951 19.9003 17.4666 20.1059 17.4149 20.306L22.3408 23.1588C23.2476 22.3154 24.597 22.1852 25.6445 22.84C26.6921 23.4948 27.1829 24.7752 26.8463 25.9749C26.5096 27.1746 25.4274 28.0016 24.1965 27.9998ZM24.1965 24.0121C23.5446 24.0121 23.016 24.5477 23.016 25.2084C23.016 25.8691 23.5446 26.4047 24.1965 26.4047C24.8485 26.4047 25.3771 25.8691 25.3771 25.2084C25.3771 24.5477 24.8485 24.0121 24.1965 24.0121ZM14.7525 18.4294C14.1005 18.4294 13.572 18.965 13.572 19.6257C13.572 20.2864 14.1005 20.822 14.7525 20.822C15.4045 20.822 15.933 20.2864 15.933 19.6257C15.933 18.965 15.4045 18.4294 14.7525 18.4294ZM24.1965 13.6442C23.5446 13.6442 23.016 14.1798 23.016 14.8405C23.016 15.5012 23.5446 16.0368 24.1965 16.0368C24.8485 16.0368 25.3771 15.5012 25.3771 14.8405C25.3771 14.1798 24.8485 13.6442 24.1965 13.6442Z"
            fill="#636363"
          />
        </svg>
      ),
    },
    {
      value: 2,
      text: 'Down Arrow',
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="40"
          height="40"
          viewBox="0 0 40 40"
          fill="none"
        >
          <script xmlns="" />
          <rect width="40" height="40" rx="5" fill="#DCDCDC" />
          <path
            d="M24.1965 27.9998C23.345 28.0098 22.5378 27.6155 22.0152 26.9341C21.4925 26.2527 21.3145 25.3628 21.5341 24.5289L16.6074 21.6754C15.7561 22.4658 14.5083 22.633 13.4834 22.0942C12.4586 21.5553 11.8751 20.425 12.0226 19.2646C12.1702 18.1042 13.0174 17.1607 14.1436 16.9027C15.2697 16.6447 16.435 17.1271 17.0608 18.1104L21.5333 15.5192C21.4755 15.2976 21.4448 15.0697 21.442 14.8405C21.4307 13.506 22.3454 12.3467 23.6324 12.0641C24.9195 11.7816 26.2256 12.4533 26.7603 13.6728C27.2951 14.8924 26.9117 16.3249 25.8421 17.1035C24.7726 17.8821 23.3106 17.793 22.3408 16.8902L17.4999 19.6935C17.4951 19.9003 17.4666 20.1059 17.4149 20.306L22.3408 23.1588C23.2476 22.3154 24.597 22.1852 25.6445 22.84C26.6921 23.4948 27.1829 24.7752 26.8463 25.9749C26.5096 27.1746 25.4274 28.0016 24.1965 27.9998ZM24.1965 24.0121C23.5446 24.0121 23.016 24.5477 23.016 25.2084C23.016 25.8691 23.5446 26.4047 24.1965 26.4047C24.8485 26.4047 25.3771 25.8691 25.3771 25.2084C25.3771 24.5477 24.8485 24.0121 24.1965 24.0121ZM14.7525 18.4294C14.1005 18.4294 13.572 18.965 13.572 19.6257C13.572 20.2864 14.1005 20.822 14.7525 20.822C15.4045 20.822 15.933 20.2864 15.933 19.6257C15.933 18.965 15.4045 18.4294 14.7525 18.4294ZM24.1965 13.6442C23.5446 13.6442 23.016 14.1798 23.016 14.8405C23.016 15.5012 23.5446 16.0368 24.1965 16.0368C24.8485 16.0368 25.3771 15.5012 25.3771 14.8405C25.3771 14.1798 24.8485 13.6442 24.1965 13.6442Z"
            fill="#636363"
          />
        </svg>
      ),
    },
    {
      value: 3,
      text: 'Left Arrow',
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="40"
          height="40"
          viewBox="0 0 40 40"
          fill="none"
        >
          <script xmlns="" />
          <rect width="40" height="40" rx="5" fill="#DCDCDC" />
          <path
            d="M24.1965 27.9998C23.345 28.0098 22.5378 27.6155 22.0152 26.9341C21.4925 26.2527 21.3145 25.3628 21.5341 24.5289L16.6074 21.6754C15.7561 22.4658 14.5083 22.633 13.4834 22.0942C12.4586 21.5553 11.8751 20.425 12.0226 19.2646C12.1702 18.1042 13.0174 17.1607 14.1436 16.9027C15.2697 16.6447 16.435 17.1271 17.0608 18.1104L21.5333 15.5192C21.4755 15.2976 21.4448 15.0697 21.442 14.8405C21.4307 13.506 22.3454 12.3467 23.6324 12.0641C24.9195 11.7816 26.2256 12.4533 26.7603 13.6728C27.2951 14.8924 26.9117 16.3249 25.8421 17.1035C24.7726 17.8821 23.3106 17.793 22.3408 16.8902L17.4999 19.6935C17.4951 19.9003 17.4666 20.1059 17.4149 20.306L22.3408 23.1588C23.2476 22.3154 24.597 22.1852 25.6445 22.84C26.6921 23.4948 27.1829 24.7752 26.8463 25.9749C26.5096 27.1746 25.4274 28.0016 24.1965 27.9998ZM24.1965 24.0121C23.5446 24.0121 23.016 24.5477 23.016 25.2084C23.016 25.8691 23.5446 26.4047 24.1965 26.4047C24.8485 26.4047 25.3771 25.8691 25.3771 25.2084C25.3771 24.5477 24.8485 24.0121 24.1965 24.0121ZM14.7525 18.4294C14.1005 18.4294 13.572 18.965 13.572 19.6257C13.572 20.2864 14.1005 20.822 14.7525 20.822C15.4045 20.822 15.933 20.2864 15.933 19.6257C15.933 18.965 15.4045 18.4294 14.7525 18.4294ZM24.1965 13.6442C23.5446 13.6442 23.016 14.1798 23.016 14.8405C23.016 15.5012 23.5446 16.0368 24.1965 16.0368C24.8485 16.0368 25.3771 15.5012 25.3771 14.8405C25.3771 14.1798 24.8485 13.6442 24.1965 13.6442Z"
            fill="#636363"
          />
        </svg>
      ),
    },
    {
      value: 4,
      text: 'Right Arrow',
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="40"
          height="40"
          viewBox="0 0 40 40"
          fill="none"
        >
          <script xmlns="" />
          <rect width="40" height="40" rx="5" fill="#DCDCDC" />
          <path
            d="M24.1965 27.9998C23.345 28.0098 22.5378 27.6155 22.0152 26.9341C21.4925 26.2527 21.3145 25.3628 21.5341 24.5289L16.6074 21.6754C15.7561 22.4658 14.5083 22.633 13.4834 22.0942C12.4586 21.5553 11.8751 20.425 12.0226 19.2646C12.1702 18.1042 13.0174 17.1607 14.1436 16.9027C15.2697 16.6447 16.435 17.1271 17.0608 18.1104L21.5333 15.5192C21.4755 15.2976 21.4448 15.0697 21.442 14.8405C21.4307 13.506 22.3454 12.3467 23.6324 12.0641C24.9195 11.7816 26.2256 12.4533 26.7603 13.6728C27.2951 14.8924 26.9117 16.3249 25.8421 17.1035C24.7726 17.8821 23.3106 17.793 22.3408 16.8902L17.4999 19.6935C17.4951 19.9003 17.4666 20.1059 17.4149 20.306L22.3408 23.1588C23.2476 22.3154 24.597 22.1852 25.6445 22.84C26.6921 23.4948 27.1829 24.7752 26.8463 25.9749C26.5096 27.1746 25.4274 28.0016 24.1965 27.9998ZM24.1965 24.0121C23.5446 24.0121 23.016 24.5477 23.016 25.2084C23.016 25.8691 23.5446 26.4047 24.1965 26.4047C24.8485 26.4047 25.3771 25.8691 25.3771 25.2084C25.3771 24.5477 24.8485 24.0121 24.1965 24.0121ZM14.7525 18.4294C14.1005 18.4294 13.572 18.965 13.572 19.6257C13.572 20.2864 14.1005 20.822 14.7525 20.822C15.4045 20.822 15.933 20.2864 15.933 19.6257C15.933 18.965 15.4045 18.4294 14.7525 18.4294ZM24.1965 13.6442C23.5446 13.6442 23.016 14.1798 23.016 14.8405C23.016 15.5012 23.5446 16.0368 24.1965 16.0368C24.8485 16.0368 25.3771 15.5012 25.3771 14.8405C25.3771 14.1798 24.8485 13.6442 24.1965 13.6442Z"
            fill="#636363"
          />
        </svg>
      ),
    },
  ];

  const [selectedOption, setSelectedOption] = useState(null);

  const handleChange = e => {
    setSelectedOption(e);
  };

  return (
    <>
      <div className="layout">
        <Grid container>
          <Grid item xs={2}>
            <div className="sidebar-div">
              <Sidebar />
            </div>
          </Grid>
          <Grid item xs={10}>
            <div className="body">
              <div className="body_top_bar">
                <MainBody heading="Numbers" breadcrumbs={breadcrumbs_data} />
              </div>
              <div className="body_content">
                <Grid
                  container
                  direction="row"
                  justifyContent="space-between"
                  alignItems="center"
                >
                  <h1>DNI Groups</h1>

                  <Popup btnname={'add'} heading={'New DNI Group'} />
                </Grid>
                <Box mt={2}>
                  <Paper className="integration_list">
                    <Accordion className="integration_list_accordion">
                      <Grid container className="DNI-group-item-text">
                        <Grid
                          item
                          xs={1}
                          container
                          direction="row"
                          justifyContent="flex-start"
                          alignItems="center"
                         
                          padding={1}
                        >
                          <img
                            src={logo}
                            alt="Integration"
                            className="integration_list_img"
                          />
                        </Grid>
                        <Grid item xs={9} >
                          <AccordionSummary
                            aria-controls="panel1a-content"
                            id="integration_list_accordion"

                          >
                            <Grid
                              container
                              direction="row"
                              justifyContent="space-between"
                              alignItems="center"
                              padding={3}
                              className="dni-group-inner-grid"
                              
                            >
                              <Grid>
                                <span className="domain_name">
                                  Five9 DNI Group
                                </span>
                              </Grid>
                              <Grid>
                                <span className="domain_number">123456789</span>
                              </Grid>
                              <Grid>
                                <span className="domain_updated_at">
                                  Last updated at 9:41 AM.
                                </span>
                              </Grid>
                            </Grid>
                          </AccordionSummary>
                        </Grid>

                        <Grid
                          item
                          xs={2}
                          container
                          
                          padding={3}
                          className="btn-group"
                          
                        >
                          <Sync btnname={"sync"} heading={"Sync"} heading2={"Syning Five9 DNI Group"}/>
                          <Edit btnname={"edit"} heading={"Edit DNI Group  "} />
                          
                        </Grid>
                      </Grid>

                      <AccordionDetails>
                        <Grid>
                          <div className="JS-File-Form">
                            <Divider />
                            <Grid container padding={2}>
                              <Grid xs={12}>
                                <div className="domain_file_name">JS File</div>
                              </Grid>
                              <Grid xs={10}>
                                <TextField
                                  fullWidth={true}
                                  id="Js-File-URL"
                                  className="domain_file_url"
                                  type={'url'}
                                  placeholder="https://custorn.url/js/abc123.js"
                                />
                              </Grid>
                              <Grid
                                xs={2}
                                container
                                direction="row"
                                justifyContent="space-evenly"
                                alignItems="center"
                              >
                                <Button
                                  size="large"
                                  variant="outlined"
                                  className="light-blue custom_h_w"
                                >
                                  <FileCopyIcon />
                                </Button>
                                <Button
                                  size="large"
                                  variant="outlined"
                                  className="light-blue custom_h_w"
                                >
                                  <CodeIcon />
                                </Button>
                              </Grid>
                            </Grid>
                          </div>
                        </Grid>
                      </AccordionDetails>
                    </Accordion>
                  </Paper>
                  <Paper className="integration_list">
                    <Accordion className="integration_list_accordion">
                      <Grid container className="DNI-group-item-text">
                        <Grid
                          item
                          xs={1}
                          container
                          direction="row"
                          justifyContent="flex-start"
                          alignItems="center"
                         
                          padding={1}
                        >
                          <img
                            src={logo}
                            alt="Integration"
                            className="integration_list_img"
                          />
                        </Grid>
                        <Grid item xs={9} >
                          <AccordionSummary
                            aria-controls="panel1a-content"
                            id="integration_list_accordion"

                          >
                            <Grid
                              container
                              direction="row"
                              justifyContent="space-between"
                              alignItems="center"
                              padding={3}
                              className="dni-group-inner-grid"
                              
                            >
                              <Grid>
                                <span className="domain_name">
                                  Five9 DNI Group
                                </span>
                              </Grid>
                              <Grid>
                                <span className="domain_number">123456789</span>
                              </Grid>
                              <Grid>
                                <span className="domain_updated_at">
                                  Last updated at 9:41 AM.
                                </span>
                              </Grid>
                            </Grid>
                          </AccordionSummary>
                        </Grid>

                        <Grid
                          item
                          xs={2}
                          container
                          
                          padding={3}
                          className="btn-group"
                          
                        >
                          <Sync btnname={"sync"} heading={"Sync"} heading2={"Syning Five9 DNI Group"}/>
                          <Edit btnname={"edit"} heading={"Edit DNI Group  "} />
                          
                        </Grid>
                      </Grid>

                      <AccordionDetails>
                        <Grid>
                          <div className="JS-File-Form">
                            <Divider />
                            <Grid container padding={2}>
                              <Grid xs={12}>
                                <div className="domain_file_name">JS File</div>
                              </Grid>
                              <Grid xs={10}>
                                <TextField
                                  fullWidth={true}
                                  id="Js-File-URL"
                                  className="domain_file_url"
                                  type={'url'}
                                  placeholder="https://custorn.url/js/abc123.js"
                                />
                              </Grid>
                              <Grid
                                xs={2}
                                container
                                direction="row"
                                justifyContent="space-evenly"
                                alignItems="center"
                              >
                                <Button
                                  size="large"
                                  variant="outlined"
                                  className="light-blue custom_h_w"
                                >
                                  <FileCopyIcon />
                                </Button>
                                <Button
                                  size="large"
                                  variant="outlined"
                                  className="light-blue custom_h_w"
                                >
                                  <CodeIcon />
                                </Button>
                              </Grid>
                            </Grid>
                          </div>
                        </Grid>
                      </AccordionDetails>
                    </Accordion>
                  </Paper>

                  <Paper className="integration_list">
                  <Accordion className="integration_list_accordion">
                    <Grid container className="DNI-group-item-text">
                      <Grid
                        item
                        xs={1}
                        container
                        direction="row"
                        justifyContent="flex-start"
                        alignItems="center"
                       
                        padding={1}
                      >
                        <img
                          src={logo}
                          alt="Integration"
                          className="integration_list_img"
                        />
                      </Grid>
                      <Grid item xs={9} >
                        <AccordionSummary
                          aria-controls="panel1a-content"
                          id="integration_list_accordion"

                        >
                          <Grid
                            container
                            direction="row"
                            justifyContent="space-between"
                            alignItems="center"
                            padding={3}
                            className="dni-group-inner-grid"
                            
                          >
                            <Grid>
                              <span className="domain_name">
                                Five9 DNI Group
                              </span>
                            </Grid>
                            <Grid>
                              <span className="domain_number">123456789</span>
                            </Grid>
                            <Grid>
                              <span className="domain_updated_at">
                                Last updated at 9:41 AM.
                              </span>
                            </Grid>
                          </Grid>
                        </AccordionSummary>
                      </Grid>

                      <Grid
                        item
                        xs={2}
                        container
                        
                        padding={3}
                        className="btn-group"
                        
                      >
                        <Sync btnname={"sync"} heading={"Sync"} heading2={"Syning Five9 DNI Group"}/>
                        <Edit btnname={"edit"} heading={"Edit DNI Group  "} />
                        
                      </Grid>
                    </Grid>

                    <AccordionDetails>
                      <Grid>
                        <div className="JS-File-Form">
                          <Divider />
                          <Grid container padding={2}>
                            <Grid xs={12}>
                              <div className="domain_file_name">JS File</div>
                            </Grid>
                            <Grid xs={10}>
                              <TextField
                                fullWidth={true}
                                id="Js-File-URL"
                                className="domain_file_url"
                                type={'url'}
                                placeholder="https://custorn.url/js/abc123.js"
                              />
                            </Grid>
                            <Grid
                              xs={2}
                              container
                              direction="row"
                              justifyContent="space-evenly"
                              alignItems="center"
                            >
                              <Button
                                size="large"
                                variant="outlined"
                                className="light-blue custom_h_w"
                              >
                                <FileCopyIcon />
                              </Button>
                              <Button
                                size="large"
                                variant="outlined"
                                className="light-blue custom_h_w"
                              >
                                <CodeIcon />
                              </Button>
                            </Grid>
                          </Grid>
                        </div>
                      </Grid>
                    </AccordionDetails>
                  </Accordion>
                </Paper>


                <Paper className="integration_list">
                    <Accordion className="integration_list_accordion">
                      <Grid container className="DNI-group-item-text">
                        <Grid
                          item
                          xs={1}
                          container
                          direction="row"
                          justifyContent="flex-start"
                          alignItems="center"
                         
                          padding={1}
                        >
                          <img
                            src={logo}
                            alt="Integration"
                            className="integration_list_img"
                          />
                        </Grid>
                        <Grid item xs={9} >
                          <AccordionSummary
                            aria-controls="panel1a-content"
                            id="integration_list_accordion"

                          >
                            <Grid
                              container
                              direction="row"
                              justifyContent="space-between"
                              alignItems="center"
                              padding={3}
                              className="dni-group-inner-grid"
                              
                            >
                              <Grid>
                                <span className="domain_name">
                                  Five9 DNI Group
                                </span>
                              </Grid>
                              <Grid>
                                <span className="domain_number">123456789</span>
                              </Grid>
                              <Grid>
                                <span className="domain_updated_at">
                                  Last updated at 9:41 AM.
                                </span>
                              </Grid>
                            </Grid>
                          </AccordionSummary>
                        </Grid>

                        <Grid
                          item
                          xs={2}
                          container
                          
                          padding={3}
                          className="btn-group"
                          
                        >
                          <Sync btnname={"sync"} heading={"Sync"} heading2={"Syning Five9 DNI Group"}/>
                          <Edit btnname={"edit"} heading={"Edit DNI Group  "} />
                          
                        </Grid>
                      </Grid>

                      <AccordionDetails>
                        <Grid>
                          <div className="JS-File-Form">
                            <Divider />
                            <Grid container padding={2}>
                              <Grid xs={12}>
                                <div className="domain_file_name">JS File</div>
                              </Grid>
                              <Grid xs={10}>
                                <TextField
                                  fullWidth={true}
                                  id="Js-File-URL"
                                  className="domain_file_url"
                                  type={'url'}
                                  placeholder="https://custorn.url/js/abc123.js"
                                />
                              </Grid>
                              <Grid
                                xs={2}
                                container
                                direction="row"
                                justifyContent="space-evenly"
                                alignItems="center"
                              >
                                <Button
                                  size="large"
                                  variant="outlined"
                                  className="light-blue custom_h_w"
                                >
                                  <FileCopyIcon />
                                </Button>
                                <Button
                                  size="large"
                                  variant="outlined"
                                  className="light-blue custom_h_w"
                                >
                                  <CodeIcon />
                                </Button>
                              </Grid>
                            </Grid>
                          </div>
                        </Grid>
                      </AccordionDetails>
                    </Accordion>
                  </Paper>

                  <Paper className="integration_list">
                    <Accordion className="integration_list_accordion">
                      <Grid container className="DNI-group-item-text">
                        <Grid
                          item
                          xs={1}
                          container
                          direction="row"
                          justifyContent="flex-start"
                          alignItems="center"
                         
                          padding={1}
                        >
                          <img
                            src={logo}
                            alt="Integration"
                            className="integration_list_img"
                          />
                        </Grid>
                        <Grid item xs={9} >
                          <AccordionSummary
                            aria-controls="panel1a-content"
                            id="integration_list_accordion"

                          >
                            <Grid
                              container
                              direction="row"
                              justifyContent="space-between"
                              alignItems="center"
                              padding={3}
                              className="dni-group-inner-grid"
                              
                            >
                              <Grid>
                                <span className="domain_name">
                                  Five9 DNI Group
                                </span>
                              </Grid>
                              <Grid>
                                <span className="domain_number">123456789</span>
                              </Grid>
                              <Grid>
                                <span className="domain_updated_at">
                                  Last updated at 9:41 AM.
                                </span>
                              </Grid>
                            </Grid>
                          </AccordionSummary>
                        </Grid>

                        <Grid
                          item
                          xs={2}
                          container
                          
                          padding={3}
                          className="btn-group"
                          
                        >
                          <Sync btnname={"sync"} heading={"Sync"} heading2={"Syning Five9 DNI Group"}/>
                          <Edit btnname={"edit"} heading={"Edit DNI Group  "} />
                          
                        </Grid>
                      </Grid>

                      <AccordionDetails>
                        <Grid>
                          <div className="JS-File-Form">
                            <Divider />
                            <Grid container padding={2}>
                              <Grid xs={12}>
                                <div className="domain_file_name">JS File</div>
                              </Grid>
                              <Grid xs={10}>
                                <TextField
                                  fullWidth={true}
                                  id="Js-File-URL"
                                  className="domain_file_url"
                                  type={'url'}
                                  placeholder="https://custorn.url/js/abc123.js"
                                />
                              </Grid>
                              <Grid
                                xs={2}
                                container
                                direction="row"
                                justifyContent="space-evenly"
                                alignItems="center"
                              >
                                <Button
                                  size="large"
                                  variant="outlined"
                                  className="light-blue custom_h_w"
                                >
                                  <FileCopyIcon />
                                </Button>
                                <Button
                                  size="large"
                                  variant="outlined"
                                  className="light-blue custom_h_w"
                                >
                                  <CodeIcon />
                                </Button>
                              </Grid>
                            </Grid>
                          </div>
                        </Grid>
                      </AccordionDetails>
                    </Accordion>
                  </Paper>
                  

                  

                  
                </Box>
              </div>
            </div>
          </Grid>
        </Grid>
      </div>
    </>
  );
};

export default Layout;
