import * as React from 'react';
import { useState, useEffect, useContext } from 'react';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Link from '@mui/material/Link';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';

import InputAdornment from '@mui/material/InputAdornment';
import { Redirect } from 'react-router-dom';
import EmailAddressIcon from './assets/img/EmailAddressIcon.svg';
import PassWordIcon from './assets/img/PassWordIcon.svg';
import LoginBanner from './assets/img/login-banner.png';

import './assets/css/style.css';
import { login } from '../../../action/AuthAction';
// require('dotenv').config();
import { useHistory } from 'react-router-dom';
// axios imported here
import axios from 'axios';
import { result } from 'lodash';
import noteContext from '../../context/noteContext';

const theme = createTheme();
const url = 'http://localhost:3344/auth/login';

export default function SignIn(props) {
  const login = useContext(noteContext);
  const intialValues = { email: '', password: '' };
  const [loginValues, setLoginValues] = useState(intialValues);
  const [loginError, setLoginError] = useState({});
  const [isLogin, setIsLogin] = useState(false);

  const [loginflag, setLoginFlag] = useState(false);
  const [logginMessage, setlogginMessage] = useState(true);
  let history = () => useHistory();

  // const Login = () => {
  // };

  const handlechange = e => {
    const { name, value } = e.target;
    setLoginValues({ ...loginValues, [name]: value });
    console.log(loginValues);
  };

  const handleLogin = e => {
    e.preventDefault();
    setLoginError(validate(loginValues));
    axios
      .post('http://localhost:3344/auth/login/', {
        email: loginValues.email,
        password: loginValues.password,
      })
      .then(res => {
        console.log(res.data);
        const accesstoken = res.data.accessToken;
        localStorage.setItem('jwtToken', accesstoken);
        // setLoginFlag(true);
        setIsLogin(true);
        setLoginFlag(true);
        setlogginMessage('Login Successfully !!!');

        login.isLogin == true;
      })
      .catch(err => {
        setIsLogin(false);
        setLoginFlag(flase  );
        setlogginMessage('Username or password invalid !!!');
      });
  };

  useEffect(() => {
    if (Object.keys(loginError).length === 0 && isLogin) {
    }
  }, [loginError]);
  const validate = values => {
    const errors = {};

    if (!values.email) {
      errors.email = 'email is require !';
    }

    if (!values.password) {
      errors.password = 'password is require !';
    }

    return errors;
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      <section class="login-main-sec">
        <div class="login-banner-area" />

        <div class="logoarea-main">
          <div class="logoarea-inner">
            <div class="logoarea-box">
              <svg
                width="322"
                height="84"
                viewBox="0 0 322 84"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M52.2173 19.964H57.3167V55.4559H72.6149V60.5553H52.2173V19.964ZM88.4995 19.964C91.5253 19.964 94.4829 20.8613 96.9987 22.5423C99.5145 24.2233 101.475 26.6124 102.633 29.4079C103.791 32.2034 104.094 35.2793 103.504 38.2467C102.913 41.2143 101.457 43.9401 99.3169 46.0796C97.1774 48.2193 94.4515 49.6762 91.484 50.2665C88.5166 50.8567 85.4406 50.5538 82.6452 49.396C79.8497 48.2379 77.4606 46.2772 75.7796 43.7614C74.0986 41.2456 73.2013 38.288 73.2013 35.2622C73.2013 33.2533 73.597 31.2638 74.3658 29.4079C75.1345 27.5517 76.2615 25.8653 77.6822 24.4449C79.1026 23.0242 80.789 21.8972 82.6452 21.1285C84.5011 20.3597 86.4906 19.964 88.4995 19.964ZM88.4995 45.461C90.5166 45.461 92.4885 44.8629 94.1657 43.7423C95.8429 42.6214 97.1501 41.0286 97.9219 39.1651C98.694 37.3015 98.8959 35.251 98.5023 33.2724C98.1088 31.2941 97.1374 29.477 95.7111 28.0507C94.2848 26.6244 92.4676 25.6529 90.4893 25.2595C88.5107 24.8658 86.4603 25.0678 84.5967 25.8398C82.7331 26.6116 81.1401 27.9188 80.0195 29.596C78.8989 31.2732 78.3007 33.2452 78.3007 35.2622C78.3142 37.9583 79.3945 40.5393 81.3058 42.4409C83.2171 44.3425 85.8035 45.41 88.4995 45.41V45.461ZM78.3007 55.5069H98.6983V60.6063H78.3007V55.5069ZM143.573 60.6063H138.474V56.9602C135.185 59.2621 131.269 60.4992 127.255 60.5043C123.832 60.5272 120.458 59.6884 117.445 58.065C114.431 56.4413 111.874 54.0857 110.011 51.2147C108.146 48.3437 107.035 45.0498 106.778 41.6362C106.522 38.2229 107.128 34.7997 108.542 31.6825C109.956 28.5649 112.131 25.8533 114.868 23.7978C117.605 21.7419 120.816 20.4079 124.203 19.9189C127.592 19.4296 131.048 19.8011 134.255 20.9987C137.461 22.1963 140.315 24.1815 142.553 26.7717L138.805 30.1118C137.103 28.2087 134.952 26.762 132.547 25.9036C130.143 25.0448 127.562 24.8016 125.039 25.196C122.517 25.5905 120.133 26.6101 118.105 28.1616C116.078 29.7133 114.471 31.7475 113.431 34.0794C112.391 36.4111 111.951 38.9659 112.152 41.5113C112.352 44.0567 113.186 46.5113 114.578 48.6515C115.97 50.7917 117.876 52.5497 120.121 53.7649C122.366 54.9801 124.88 55.6139 127.433 55.6088C129.552 55.6132 131.647 55.1598 133.575 54.2797C135.502 53.3995 137.217 52.1135 138.601 50.5094H124.833V45.41H143.624L143.573 60.6063ZM162.339 20.066C165.365 20.066 168.322 20.9633 170.838 22.6443C173.354 24.3253 175.315 26.7144 176.473 29.5099C177.63 32.3053 177.933 35.3813 177.343 38.3486C176.753 41.3162 175.296 44.0421 173.156 46.1816C171.017 48.3213 168.291 49.7782 165.323 50.3684C162.356 50.9587 159.28 50.6558 156.484 49.498C153.689 48.3399 151.3 46.3792 149.619 43.8634C147.938 41.3476 147.041 38.39 147.041 35.3642C147.027 33.3423 147.415 31.338 148.181 29.4668C148.947 27.5955 150.076 25.8946 151.503 24.4627C152.93 23.0306 154.628 21.8957 156.496 21.1234C158.365 20.3513 160.368 19.9571 162.39 19.964L162.339 20.066ZM162.339 45.563C164.356 45.563 166.328 44.9649 168.005 43.8443C169.682 42.7234 170.989 41.1306 171.761 39.267C172.533 37.4035 172.735 35.353 172.342 33.3744C171.948 31.3961 170.977 29.5789 169.55 28.1526C168.124 26.7263 166.307 25.7549 164.329 25.3615C162.35 24.9678 160.3 25.1698 158.436 25.9418C156.572 26.7136 154.979 28.0208 153.859 29.698C152.738 31.3752 152.14 33.3472 152.14 35.3642C152.18 38.0514 153.28 40.6141 155.199 42.4952C157.118 44.3761 159.702 45.4238 162.39 45.41L162.339 45.563ZM152.14 55.6088H172.538V60.7082H152.14V55.6088ZM183.068 19.964H188.167V60.5043H183.068V19.964ZM195.23 19.964H200.329C200.592 19.9362 200.857 19.9362 201.12 19.964C203.255 19.7323 205.416 19.9531 207.461 20.6117C209.505 21.2705 211.388 22.3523 212.987 23.787C214.586 25.2218 215.865 26.9772 216.74 28.939C217.616 30.9007 218.068 33.0249 218.068 35.173C218.068 37.3211 217.616 39.4453 216.74 41.407C215.865 43.3687 214.586 45.1242 212.987 46.5589C211.388 47.9937 209.505 49.0755 207.461 49.7343C205.416 50.3929 203.255 50.6137 201.12 50.382H200.329V60.5808H195.23V19.964ZM200.329 25.0634V45.2316H201.12C202.56 45.4233 204.025 45.3052 205.416 44.8848C206.807 44.4646 208.092 43.752 209.185 42.7948C210.278 41.8377 211.154 40.6579 211.754 39.3346C212.354 38.0113 212.665 36.5751 212.665 35.122C212.665 33.6689 212.354 32.2327 211.754 30.9094C211.154 29.5861 210.278 28.4063 209.185 27.4492C208.092 26.4918 206.807 25.7794 205.416 25.3589C204.025 24.9388 202.56 24.8207 201.12 25.0124C200.842 25.0412 200.568 25.1012 200.304 25.1909L200.329 25.0634ZM237.071 22.8962L233.297 25.8793C232.646 25.1991 231.814 24.7187 230.9 24.4948C229.985 24.271 229.026 24.3128 228.134 24.6154C227.242 24.9178 226.456 25.4686 225.866 26.2029C225.277 26.9372 224.909 27.8245 224.807 28.7605V29.1684C224.807 31.4122 226.362 32.9165 229.396 33.1205C241.074 33.8344 246.428 39.3163 246.428 46.5574V47.0164C246.126 49.8822 245.008 52.6012 243.206 54.8501C241.404 57.0989 238.994 58.7825 236.262 59.7011C233.531 60.6195 230.593 60.7343 227.798 60.0313C225.004 59.3286 222.469 57.8378 220.498 55.7363L224.399 52.7277C225.307 53.7009 226.415 54.4648 227.648 54.9668C228.881 55.4686 230.208 55.6966 231.538 55.6343C233.994 55.7639 236.404 54.9395 238.267 53.3335C240.129 51.7277 241.299 49.4643 241.533 47.0164V46.6594C241.533 39.8517 234.852 38.6023 229.065 38.0414C223.71 37.5315 219.86 34.1914 219.86 29.3724V29.1684C220.049 26.6595 221.194 24.3189 223.058 22.63C224.923 20.9408 227.365 20.0321 229.88 20.0915C231.213 20.0522 232.54 20.2927 233.774 20.7978C235.008 21.3029 236.122 22.0612 237.045 23.0237L237.071 22.8962ZM266.392 55.3284C272.741 55.3284 277.764 48.4697 277.764 40.0302V19.6326H282.863V40.0302C282.863 51.2489 275.52 60.3003 266.494 60.3003C257.468 60.3003 250.125 51.2489 250.125 40.0302V19.6326H255.224V40.0302C255.02 48.5972 260.043 55.4559 266.367 55.4559L266.392 55.3284ZM322.001 60.4278H316.902V35.1857L305.148 50.4839L293.393 35.1857V60.5043H288.294V19.964L305.122 42.1209L321.95 19.964L322.001 60.4278Z"
                  fill="#2F80ED"
                />
                <path
                  d="M27.7403 13.8704C27.7403 10.1917 26.279 6.66372 23.6778 4.06254C21.0766 1.46134 17.5485 0 13.8699 0C10.1912 0 6.66326 1.46134 4.06205 4.06254C1.46085 6.66372 -0.000488281 10.1917 -0.000488281 13.8704V55.813L11.4222 63.9975V83.9361H16.3176V63.9975L27.7403 55.813V13.8704ZM22.8448 37.3276L16.3176 43.8549V37.7356L22.8448 31.2083V37.3276ZM4.99693 31.2083L11.5242 37.7356V43.8549L4.99693 37.3276V31.2083ZM22.8448 24.2732L13.8699 33.2481L4.89494 24.0692V17.9499L13.8699 26.9248L22.8448 17.9499V24.2732ZM13.8699 4.89543C15.8437 4.90415 17.7603 5.5597 19.326 6.76163C20.8918 7.96356 22.0203 9.64559 22.5389 11.5501L13.8699 20.1936L5.2009 11.5501C5.70049 9.62665 6.82091 7.92179 8.38836 6.70013C9.95581 5.47844 11.8826 4.8082 13.8699 4.79341V4.89543ZM4.89494 53.3397V44.1608L11.4222 50.6881V57.9802L4.89494 53.3397ZM16.3176 58.0057V50.6881L22.8448 44.1608V53.3142L16.3176 58.0057Z"
                  fill="#2F80ED"
                />
              </svg>
            </div>
          </div>
        </div>

        <div class="login-form-area">
          <div class="login-form-area-inner">
            <div class="login-form-content">
              <h2>
                <span>Login</span>
              </h2>
              <Container>
                <Box component="form" noValidate>
                  <TextField
                    className="email-text-field"
                    margin="normal"
                    required
                    fullWidth
                    id="input-with-icon-textfield"
                    name="email"
                    placeholder="Email Address"
                    value={loginValues.email}
                    onChange={handlechange}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <img src={EmailAddressIcon} alt="Email Address" />
                        </InputAdornment>
                      ),
                    }}
                  />
                  <p className="login-errors">{loginError.email}</p>
                  <TextField
                    className="password-text-field"
                    margin="normal"
                    required
                    fullWidth
                    name="password"
                    type="password"
                    placeholder="Password"
                    id="password"
                    value={loginValues.password}
                    onChange={handlechange}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <img src={PassWordIcon} alt="PassWord" />
                        </InputAdornment>
                      ),
                    }}
                  />
                  <p className="login-errors">{loginError.password}</p>
                  <p
                    style={{
                      textAlign: 'left',
                      color: isLogin == true ? 'green' : 'red',
                    }}
                  >
                    {logginMessage}
                  </p>
                  <Grid container alignItems="center">
                    <Grid item xs>
                      <Button
                        className="login-btn-text-field"
                        variant="contained"
                        onClick={handleLogin}
                        sx={{ mt: 3, mb: 2 }}
                      >
                        LOG IN
                      </Button>
                    </Grid>

                    <Grid item>
                      <Link
                        href="/forgotpassword"
                        variant="body2"
                        className="forgot-btn-text-field"
                      >
                        Forgot password?
                      </Link>
                    </Grid>
                  </Grid>
                </Box>
              </Container>
            </div>
          </div>
        </div>
      </section>
    </Box>
  );
}
