import React from 'react';
import './assets/css/style.css';
import Grid from '@mui/material/Grid';
import Link from '@mui/material/Link';

/** Create breadcrumb based on array with > sign */

function breadcrumbs(breadcrumbs_data) {

  const breadcrumbs_html = breadcrumbs_data.map((breadcrumb, index) => {
    if (index === breadcrumbs_data.length - 1) {
      return (
        <>
          <span style={{ color: '#414141' }} key={index}>{breadcrumb}</span>
        </>
      );
    } else {
      return (
        <>
          <span key={index}>
            {breadcrumb}
          </span>
          <span className='breadcrumbs_saprator'>
            <svg xmlns="http://www.w3.org/2000/svg" width="6" height="10" viewBox="0 0 6 10" fill="none"><script xmlns="" />
              <path d="M1 9L5 5L1 1" stroke="#414141" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
          </span>
        </>
      );
    }
  });

  return breadcrumbs_html;
}

function index(props) {
  return (
    <div className="navigation-container">
      <Grid>
        <h2> {props.heading} </h2>
        <h4>
          {breadcrumbs(props.breadcrumbs)}
        </h4>
      </Grid>
    </div>
  );
}

export default index;
