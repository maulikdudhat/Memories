import React from 'react'
import './assets/css/style.css'
function index() {
    return (
        <div className='Topnav'>
            this is top bar from
        </div>
    )
}

export default index
