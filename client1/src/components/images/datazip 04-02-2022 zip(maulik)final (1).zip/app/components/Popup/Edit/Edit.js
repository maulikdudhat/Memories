import React, { useState } from 'react';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import Button from '@mui/material/Button';
// import Editicon from '../../../../app/images/editicon.svg';
import closeicon from '../../../../app/images/closeicon.svg';
import backicon from '../../../../app/images/backicon.svg'
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Select from 'react-select';

// deletepop up  resource

import dustbinicon from '../../../../app/images/dustbinicon.svg'
import canclebtn from '../../../../app/images/canclebtn.svg'
import deletebtnpopup from '../../../../app/images/deletebtnprimarycolor.svg'





import FormControlLabel from '@mui/material/FormControlLabel';


import './asset/style.css';
// import NextButton from '../../../../'
// import invitebtn from '../../images/invitebtn.svg';

// table components imported here
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Typography from '@mui/material/Typography';
import { Stepper, Step } from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import Card from '@mui/material/Card';

import Deletebtn from './Delete'
// import AddParameter from './AddParameter';
import { margin } from '@mui/system';

import AddParameter from '../../Popup/Edit/AddParameter'
import Delete from './Delete';



const styledlt = {
  position: 'absolute',
  top: '28%',
  left: '36%',
  // width:'100%',  
  
  background: '#fff',
  borderRadius: '5px',


}
const style1 = {
  background: 'var(--delete-color)',
  color: 'white',
  display: 'flex',
  jutifyContent: 'space-around',
  width: '59vh',
  display: 'flex',
  height: '70px',
  borderRadius: 'none',



}

 function deletebtn(handleopen){
   const del = handleopen = () => setOpen(true);   
   return del;
}




function createData(source, calories, fat, carbs, protein) {
  return { source, calories, fat, carbs, protein };
}

function index(props) {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [selectedOption, setSelectedOption] = useState(null);

  const handleChange1 = e => {
    setSelectedOption(e);
  };
  const handleChange2 = e => {
    setSelectedOption(e);
  };

  const [activeStep, setActiveStep] = React.useState(0);

  const handleNext = () => {
    if(activeStep === 0){
    setActiveStep(activeStep + 1)
    console.log(activeStep)
  }

  // const deleteonclick =()=>{
    


 
  

    
  }

  const handleBack = () => {
    if(activeStep <=2 && activeStep>0){
    setActiveStep(activeStep - 1)

    console.log(activeStep )

    }
    
  }
  const [active, setActive] = useState('');

  function getstep() {
    return ["0","1",
      ]
  }
  const step = getstep();

  function getStepContent(step) {
    switch (step) {
      case 0:
        return (
          <>
            <Grid
              sx={{
                flexGrow: 1,
                height: '60px !important',
                width: '500px !important',
              }}
              container
              style={{}}
            >
              <Grid item xs={12}>
                <Grid
                  container
                  justifyContent="center"
                  flexDirection="column"
                >
                  <Select
                    placeholder="Select Campaing..."
                    className="integration-drop-down-input-select"
                    // value={selectedOption}

                    onChange={handleChange1}
                    
                    getOptionLabel={e => (
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'left',
                          padding: '0px',
                        }}
                      >

                        <span style={{ marginLeft: 5 }}>{e.text}</span>
                      </div>
                    )}
                  />
                </Grid>
              </Grid>
            </Grid>
            <div className='table-outer-div'>
            <TableContainer
              // component={Paper}
              className="edit-table-container"
            >
              <Table
                sx={{}}
                aria-label="simple table"
                className="edit-table"
              >
                <TableHead>
                  <TableRow >
                    <TableCell className="table-head">Number</TableCell>
                    <TableCell align="right" className="table-head">
                      Default
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody className='table-body'>
                  {rows.map(row => (
                    <TableRow
                      key={row.source}
                      sx={{
                        '&:last-child td, &:last-child th': { border: 0 },
                      }}
                    >
                      <TableCell component="th" scope="row">
                        {row.source}
                      </TableCell>
                      <TableCell align="right">{row.calories}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            </div>
            <Grid
              sx={{
                flexGrow: 1,
                height: '60px !important',
                width: '760px !important',
              }}
              container
              style={{}}
            >
              <Grid item xs={12}>
                <Grid
                  container
                  justifyContent="center"
                  flexDirection="column"
                >
                  <Select
                    placeholder="Select Style..."
                    className="integration-drop-down-input-select"
                    // value={selectedOption}
                    // options={select_data}
                    onChange={handleChange2}
                    getOptionLabel={e => (
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          padding: '10px',
                        }}
                      >
                        <span style={{ marginLeft: 5 }}>{e.text}</span>
                      </div>
                    )}
                  />
                </Grid>
              </Grid>
            </Grid>

            <Paper className='edit-dni-group' elevation={0} >
              <Typography className='list-dni-group'>Expirationtime(s):</Typography>
              <Card variant="text" style={{ color: 'var(--main-bg)', padding: '12px', paddingLeft: '15px', width: '100px', height: 'auto', marginRight: '10px' }}> 1234 </Card>
            </Paper>
          </>
        );


      default:
        return (
          <>

            <Box className='edit-popup-box' >
            <Grid container spacing={2} padding={2} >
              <Grid item xs={6} className='edit-dni-group-second-tab-grid'>
                <Paper className='edit-dni-group-second-tab-paper'>
                  <FormControlLabel control={<Checkbox  />} label="facebook" style={{ marginLeft:'5px'}}/>
                </Paper>

              </Grid>
              <Grid item xs={6} style={{ margin: '00px !important' }}>
              <Paper className='edit-dni-group-second-tab-paper'>
                  <FormControlLabel control={<Checkbox  />} label="UTM" style={{ marginLeft:'5px'}}/>
                </Paper>

              </Grid>
              <Grid item xs={6} className='edit-dni-group-second-tab-grid'>
              <Paper className='edit-dni-group-second-tab-paper'>
                  <FormControlLabel control={<Checkbox  />} label="Google ads" style={{ marginLeft:'5px'}}/>
                </Paper>

              </Grid>
              <Grid item xs={6} style={{ margin: '10px !important' }}>
              <Paper className='edit-dni-group-second-tab-paper'>
                  <FormControlLabel control={<Checkbox  />} label="Bring Ads" style={{ marginLeft:'5px'}}/>
                </Paper>

              </Grid>
              <Grid item xs={6} className='edit-dni-group-second-tab-grid'>
              <Paper className='edit-dni-group-second-tab-paper'>
                  <FormControlLabel control={<Checkbox  />} label="Google Analytics" style={{ marginLeft:'5px'}}/>
                </Paper>

              </Grid>
              <Grid item xs={6} style={{ margin: '10px !important' }}>
              <Paper className='edit-dni-group-second-tab-paper'>
                  <FormControlLabel control={<Checkbox  />} label="TBD" style={{ marginLeft:'5px'}}/>
                </Paper>

              </Grid>
            </Grid>
            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
              {/* <Button variant="outlined" color="primary" style={{ marginRight: '20px' }} onClick={() => setActive('addCustomeparam')}>Add Custome Param</Button> */}
              <AddParameter btnname="add Custome param" />
            </div>
            <TableContainer
              component={Paper}
              className="edit-table-container"
            >
              <Table
                sx={{}}
                aria-label="simple table"
                className="edit-table"
              >
                <TableHead>
                  <TableRow >
                    <TableCell className="table-head">Source</TableCell>
                    <TableCell align="right" className="table-head">
                      Location
                    </TableCell>
                    <TableCell align="right" className="table-head">
                      Name
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody className='table-body'>
                  {rows.map(row => (
                    <TableRow
                      key={row.source}
                      sx={{
                        '&:last-child td, &:last-child th': { border: 0 },
                      }}
                    >
                      <TableCell component="th" scope="row">
                        {row.source}
                      </TableCell>
                      <TableCell align="right">{row.calories}</TableCell>
                      <TableCell align="right">{row.calories}</TableCell>

                    </TableRow>
                  ))}
                </TableBody>
              </Table>  
            </TableContainer>
            </Box>

          </>
        );
    }
  }
  const rows = [
    createData('Frozen yoghurt', 159, 'fbclid'),
    createData('Ice cream sandwich', 237, 'fbclid'),
    createData('Ice cream sandwich', 237, 'fbclid'),
  ];
  const style2 = {
   
  };

  const select_data = [
    {
      value: 1,
      text: 'Up Arrow',
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="40"
          height="40"
          viewBox="0 0 40 40"
          fill="none"
        >
          <script xmlns="" />
          <rect width="40" height="40" rx="5" fill="#DCDCDC" />
          <path
            d="M24.1965 27.9998C23.345 28.0098 22.5378 27.6155 22.0152 26.9341C21.4925 26.2527 21.3145 25.3628 21.5341 24.5289L16.6074 21.6754C15.7561 22.4658 14.5083 22.633 13.4834 22.0942C12.4586 21.5553 11.8751 20.425 12.0226 19.2646C12.1702 18.1042 13.0174 17.1607 14.1436 16.9027C15.2697 16.6447 16.435 17.1271 17.0608 18.1104L21.5333 15.5192C21.4755 15.2976 21.4448 15.0697 21.442 14.8405C21.4307 13.506 22.3454 12.3467 23.6324 12.0641C24.9195 11.7816 26.2256 12.4533 26.7603 13.6728C27.2951 14.8924 26.9117 16.3249 25.8421 17.1035C24.7726 17.8821 23.3106 17.793 22.3408 16.8902L17.4999 19.6935C17.4951 19.9003 17.4666 20.1059 17.4149 20.306L22.3408 23.1588C23.2476 22.3154 24.597 22.1852 25.6445 22.84C26.6921 23.4948 27.1829 24.7752 26.8463 25.9749C26.5096 27.1746 25.4274 28.0016 24.1965 27.9998ZM24.1965 24.0121C23.5446 24.0121 23.016 24.5477 23.016 25.2084C23.016 25.8691 23.5446 26.4047 24.1965 26.4047C24.8485 26.4047 25.3771 25.8691 25.3771 25.2084C25.3771 24.5477 24.8485 24.0121 24.1965 24.0121ZM14.7525 18.4294C14.1005 18.4294 13.572 18.965 13.572 19.6257C13.572 20.2864 14.1005 20.822 14.7525 20.822C15.4045 20.822 15.933 20.2864 15.933 19.6257C15.933 18.965 15.4045 18.4294 14.7525 18.4294ZM24.1965 13.6442C23.5446 13.6442 23.016 14.1798 23.016 14.8405C23.016 15.5012 23.5446 16.0368 24.1965 16.0368C24.8485 16.0368 25.3771 15.5012 25.3771 14.8405C25.3771 14.1798 24.8485 13.6442 24.1965 13.6442Z"
            fill="#636363"
          />
        </svg>
      ),
    },
    {
      value: 2,
      text: 'Down Arrow',
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="40"
          height="40"
          viewBox="0 0 40 40"
          fill="none"
        >
          <script xmlns="" />
          <rect width="40" height="40" rx="5" fill="#DCDCDC" />
          <path
            d="M24.1965 27.9998C23.345 28.0098 22.5378 27.6155 22.0152 26.9341C21.4925 26.2527 21.3145 25.3628 21.5341 24.5289L16.6074 21.6754C15.7561 22.4658 14.5083 22.633 13.4834 22.0942C12.4586 21.5553 11.8751 20.425 12.0226 19.2646C12.1702 18.1042 13.0174 17.1607 14.1436 16.9027C15.2697 16.6447 16.435 17.1271 17.0608 18.1104L21.5333 15.5192C21.4755 15.2976 21.4448 15.0697 21.442 14.8405C21.4307 13.506 22.3454 12.3467 23.6324 12.0641C24.9195 11.7816 26.2256 12.4533 26.7603 13.6728C27.2951 14.8924 26.9117 16.3249 25.8421 17.1035C24.7726 17.8821 23.3106 17.793 22.3408 16.8902L17.4999 19.6935C17.4951 19.9003 17.4666 20.1059 17.4149 20.306L22.3408 23.1588C23.2476 22.3154 24.597 22.1852 25.6445 22.84C26.6921 23.4948 27.1829 24.7752 26.8463 25.9749C26.5096 27.1746 25.4274 28.0016 24.1965 27.9998ZM24.1965 24.0121C23.5446 24.0121 23.016 24.5477 23.016 25.2084C23.016 25.8691 23.5446 26.4047 24.1965 26.4047C24.8485 26.4047 25.3771 25.8691 25.3771 25.2084C25.3771 24.5477 24.8485 24.0121 24.1965 24.0121ZM14.7525 18.4294C14.1005 18.4294 13.572 18.965 13.572 19.6257C13.572 20.2864 14.1005 20.822 14.7525 20.822C15.4045 20.822 15.933 20.2864 15.933 19.6257C15.933 18.965 15.4045 18.4294 14.7525 18.4294ZM24.1965 13.6442C23.5446 13.6442 23.016 14.1798 23.016 14.8405C23.016 15.5012 23.5446 16.0368 24.1965 16.0368C24.8485 16.0368 25.3771 15.5012 25.3771 14.8405C25.3771 14.1798 24.8485 13.6442 24.1965 13.6442Z"
            fill="#636363"
          />
        </svg>
      ),
    },
    {
      value: 3,
      text: 'Left Arrow',
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="40"
          height="40"
          viewBox="0 0 40 40"
          fill="none"
        >
          <script xmlns="" />
          <rect width="40" height="40" rx="5" fill="#DCDCDC" />
          <path
            d="M24.1965 27.9998C23.345 28.0098 22.5378 27.6155 22.0152 26.9341C21.4925 26.2527 21.3145 25.3628 21.5341 24.5289L16.6074 21.6754C15.7561 22.4658 14.5083 22.633 13.4834 22.0942C12.4586 21.5553 11.8751 20.425 12.0226 19.2646C12.1702 18.1042 13.0174 17.1607 14.1436 16.9027C15.2697 16.6447 16.435 17.1271 17.0608 18.1104L21.5333 15.5192C21.4755 15.2976 21.4448 15.0697 21.442 14.8405C21.4307 13.506 22.3454 12.3467 23.6324 12.0641C24.9195 11.7816 26.2256 12.4533 26.7603 13.6728C27.2951 14.8924 26.9117 16.3249 25.8421 17.1035C24.7726 17.8821 23.3106 17.793 22.3408 16.8902L17.4999 19.6935C17.4951 19.9003 17.4666 20.1059 17.4149 20.306L22.3408 23.1588C23.2476 22.3154 24.597 22.1852 25.6445 22.84C26.6921 23.4948 27.1829 24.7752 26.8463 25.9749C26.5096 27.1746 25.4274 28.0016 24.1965 27.9998ZM24.1965 24.0121C23.5446 24.0121 23.016 24.5477 23.016 25.2084C23.016 25.8691 23.5446 26.4047 24.1965 26.4047C24.8485 26.4047 25.3771 25.8691 25.3771 25.2084C25.3771 24.5477 24.8485 24.0121 24.1965 24.0121ZM14.7525 18.4294C14.1005 18.4294 13.572 18.965 13.572 19.6257C13.572 20.2864 14.1005 20.822 14.7525 20.822C15.4045 20.822 15.933 20.2864 15.933 19.6257C15.933 18.965 15.4045 18.4294 14.7525 18.4294ZM24.1965 13.6442C23.5446 13.6442 23.016 14.1798 23.016 14.8405C23.016 15.5012 23.5446 16.0368 24.1965 16.0368C24.8485 16.0368 25.3771 15.5012 25.3771 14.8405C25.3771 14.1798 24.8485 13.6442 24.1965 13.6442Z"
            fill="#636363"
          />
        </svg>
      ),
    },
    {
      value: 4,
      text: 'Right Arrow',
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="40"
          height="40"
          viewBox="0 0 40 40"
          fill="none"
        >
          <script xmlns="" />
          <rect width="40" height="40" rx="5" fill="#DCDCDC" />
          <path
            d="M24.1965 27.9998C23.345 28.0098 22.5378 27.6155 22.0152 26.9341C21.4925 26.2527 21.3145 25.3628 21.5341 24.5289L16.6074 21.6754C15.7561 22.4658 14.5083 22.633 13.4834 22.0942C12.4586 21.5553 11.8751 20.425 12.0226 19.2646C12.1702 18.1042 13.0174 17.1607 14.1436 16.9027C15.2697 16.6447 16.435 17.1271 17.0608 18.1104L21.5333 15.5192C21.4755 15.2976 21.4448 15.0697 21.442 14.8405C21.4307 13.506 22.3454 12.3467 23.6324 12.0641C24.9195 11.7816 26.2256 12.4533 26.7603 13.6728C27.2951 14.8924 26.9117 16.3249 25.8421 17.1035C24.7726 17.8821 23.3106 17.793 22.3408 16.8902L17.4999 19.6935C17.4951 19.9003 17.4666 20.1059 17.4149 20.306L22.3408 23.1588C23.2476 22.3154 24.597 22.1852 25.6445 22.84C26.6921 23.4948 27.1829 24.7752 26.8463 25.9749C26.5096 27.1746 25.4274 28.0016 24.1965 27.9998ZM24.1965 24.0121C23.5446 24.0121 23.016 24.5477 23.016 25.2084C23.016 25.8691 23.5446 26.4047 24.1965 26.4047C24.8485 26.4047 25.3771 25.8691 25.3771 25.2084C25.3771 24.5477 24.8485 24.0121 24.1965 24.0121ZM14.7525 18.4294C14.1005 18.4294 13.572 18.965 13.572 19.6257C13.572 20.2864 14.1005 20.822 14.7525 20.822C15.4045 20.822 15.933 20.2864 15.933 19.6257C15.933 18.965 15.4045 18.4294 14.7525 18.4294ZM24.1965 13.6442C23.5446 13.6442 23.016 14.1798 23.016 14.8405C23.016 15.5012 23.5446 16.0368 24.1965 16.0368C24.8485 16.0368 25.3771 15.5012 25.3771 14.8405C25.3771 14.1798 24.8485 13.6442 24.1965 13.6442Z"
            fill="#636363"
          />
        </svg>
      ),
    },
  ];
  const [open1, setOpen1] = React.useState(false);
  const handleOpendlt = () => setOpen1(true);
  const handleClosedlt = () => setOpen1(false);

  return (

    <>
      <Button
        size="large"
        variant="outlined"
        className="light-blue"
        id="popup-edit-btn-dni-group"
        onClick={handleOpen}
      >
        {props.btnname}
      </Button>

      <Grid
        container
        direction="row"
        justifyContent="space-between"
        alignItems="center"
      >
        <Modal
          open={open}
          onClose={handleClose}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
          backdrop="static"
          keyboard="false"
        >
          <Box  className="edit-popup-main-box">
            <div className="edit" style={{ position: 'fixed' }}>
              <div className="edit-inner">
                <div className="edit-header">
                  <div>
                    <h3>{props.heading}</h3>
                  </div>

                  <div className="edit-close">
                    <a onClick={handleBack}>
                   

                    </a>
                  </div>
                  <div className="edit-close">
                    <a onClick={handleClose}>
                      <img src={closeicon} />
                    </a>
                  </div>
                </div>
                <div>
                </div>

                <form>
                  {getStepContent(activeStep)
                  }
                </form> 

                <div className="edit-footer">
                  
                  <Button variant="outlined" className='backbtn' style={{ backgroundColor:'var(--main-bg)', color:'white',width:'126px', border:'1px solid white'}} onClick={activeStep == 0 ? handleOpendlt:handleBack}>{activeStep == 0 ? 'Delete' : ' Back'} </Button>

                  <Button variant="contained" className='nextbtn' style={{background:'white', color:'var(--main-bg)', width:'126px', height:'48'}} onClick={handleNext} >{activeStep == 0 ? 'next' : 'save'}</Button>
                  

                </div>
              </div>
            </div>
          </Box>

        </Modal>
      </Grid>
      <div>
            {/* <Button varient="outlined" onClick={} > Delete</Button> */}
            <Modal
                open={open1}
                onClose={handleClosedlt}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
                
            >
                <Grid container >
                    <Box sx={styledlt}>
                        <Paper sx={style1}>
                            <Grid container xs={12} style={{ display: 'flex', justifyContent: 'flex-start', margin: '0px' }}>
                                <h2 style={{ paddingLeft: '20px' }}>Delete</h2>
                            </Grid>
                            <Grid className="close-icon-user-profile">
                                <a onClick={handleClosedlt}>
                                    <img src={closeicon} />
                                </a>
                            </Grid>
                        </Paper>
                        <Paper className="delete-body">
                            <Grid>
                                <img src={dustbinicon}></img>
                            </Grid>
                            <Grid>
                                <Typography variant="h4">Are you sure ?</Typography>
                            </Grid>
                            <Grid>
                                <Typography >
                                    <span>Do you really want to delete these integration?</span><br></br> <span>This process cannot be undone</span></Typography>
                            </Grid>

                            <Grid className="delete-btn-group" style={{margin:'20px'}}>
                                <a style={{cursor:'pointer'}}>
                                    <img src={canclebtn} style={{marginRight:'00px'}}></img>
                                </a>
                                <a style={{cursor:'pointer'}}>
                                <img src={deletebtnpopup}></img>

                                </a>
                            </Grid>

                        </Paper>
                    </Box>

                </Grid>

            </Modal>
        </div>

    </>

  );
}

export default index;
