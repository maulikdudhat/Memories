import React, { useState } from 'react'
import { Grid } from '@mui/material';
import { Select, Button } from '@mui/material';
import Box from '@mui/material/Box';
import { Modal } from '@mui/material';
import backicon from '../../../images/backicon.svg'
import closeicon from '../../../images/closeicon.svg'
import { Paper, Card } from '@mui/material';
import { Typography } from '@mui/material';
import './Addparameter.css'





const select_data_parameter = [
    {
        value: 1,
        text: 'Up Arrow',
        icon: (
            <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 40 40"
                fill="none"
            >
                <script xmlns="" />
                <rect width="40" height="40" rx="5" fill="#DCDCDC" />
                <path
                    d="M24.1965 27.9998C23.345 28.0098 22.5378 27.6155 22.0152 26.9341C21.4925 26.2527 21.3145 25.3628 21.5341 24.5289L16.6074 21.6754C15.7561 22.4658 14.5083 22.633 13.4834 22.0942C12.4586 21.5553 11.8751 20.425 12.0226 19.2646C12.1702 18.1042 13.0174 17.1607 14.1436 16.9027C15.2697 16.6447 16.435 17.1271 17.0608 18.1104L21.5333 15.5192C21.4755 15.2976 21.4448 15.0697 21.442 14.8405C21.4307 13.506 22.3454 12.3467 23.6324 12.0641C24.9195 11.7816 26.2256 12.4533 26.7603 13.6728C27.2951 14.8924 26.9117 16.3249 25.8421 17.1035C24.7726 17.8821 23.3106 17.793 22.3408 16.8902L17.4999 19.6935C17.4951 19.9003 17.4666 20.1059 17.4149 20.306L22.3408 23.1588C23.2476 22.3154 24.597 22.1852 25.6445 22.84C26.6921 23.4948 27.1829 24.7752 26.8463 25.9749C26.5096 27.1746 25.4274 28.0016 24.1965 27.9998ZM24.1965 24.0121C23.5446 24.0121 23.016 24.5477 23.016 25.2084C23.016 25.8691 23.5446 26.4047 24.1965 26.4047C24.8485 26.4047 25.3771 25.8691 25.3771 25.2084C25.3771 24.5477 24.8485 24.0121 24.1965 24.0121ZM14.7525 18.4294C14.1005 18.4294 13.572 18.965 13.572 19.6257C13.572 20.2864 14.1005 20.822 14.7525 20.822C15.4045 20.822 15.933 20.2864 15.933 19.6257C15.933 18.965 15.4045 18.4294 14.7525 18.4294ZM24.1965 13.6442C23.5446 13.6442 23.016 14.1798 23.016 14.8405C23.016 15.5012 23.5446 16.0368 24.1965 16.0368C24.8485 16.0368 25.3771 15.5012 25.3771 14.8405C25.3771 14.1798 24.8485 13.6442 24.1965 13.6442Z"
                    fill="#636363"
                />
            </svg>
        ),
    },
    {
        value: 2,
        text: 'Down Arrow',
        icon: (
            <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 40 40"
                fill="none"
            >
                <script xmlns="" />
                <rect width="40" height="40" rx="5" fill="#DCDCDC" />
                <path
                    d="M24.1965 27.9998C23.345 28.0098 22.5378 27.6155 22.0152 26.9341C21.4925 26.2527 21.3145 25.3628 21.5341 24.5289L16.6074 21.6754C15.7561 22.4658 14.5083 22.633 13.4834 22.0942C12.4586 21.5553 11.8751 20.425 12.0226 19.2646C12.1702 18.1042 13.0174 17.1607 14.1436 16.9027C15.2697 16.6447 16.435 17.1271 17.0608 18.1104L21.5333 15.5192C21.4755 15.2976 21.4448 15.0697 21.442 14.8405C21.4307 13.506 22.3454 12.3467 23.6324 12.0641C24.9195 11.7816 26.2256 12.4533 26.7603 13.6728C27.2951 14.8924 26.9117 16.3249 25.8421 17.1035C24.7726 17.8821 23.3106 17.793 22.3408 16.8902L17.4999 19.6935C17.4951 19.9003 17.4666 20.1059 17.4149 20.306L22.3408 23.1588C23.2476 22.3154 24.597 22.1852 25.6445 22.84C26.6921 23.4948 27.1829 24.7752 26.8463 25.9749C26.5096 27.1746 25.4274 28.0016 24.1965 27.9998ZM24.1965 24.0121C23.5446 24.0121 23.016 24.5477 23.016 25.2084C23.016 25.8691 23.5446 26.4047 24.1965 26.4047C24.8485 26.4047 25.3771 25.8691 25.3771 25.2084C25.3771 24.5477 24.8485 24.0121 24.1965 24.0121ZM14.7525 18.4294C14.1005 18.4294 13.572 18.965 13.572 19.6257C13.572 20.2864 14.1005 20.822 14.7525 20.822C15.4045 20.822 15.933 20.2864 15.933 19.6257C15.933 18.965 15.4045 18.4294 14.7525 18.4294ZM24.1965 13.6442C23.5446 13.6442 23.016 14.1798 23.016 14.8405C23.016 15.5012 23.5446 16.0368 24.1965 16.0368C24.8485 16.0368 25.3771 15.5012 25.3771 14.8405C25.3771 14.1798 24.8485 13.6442 24.1965 13.6442Z"
                    fill="#636363"
                />
            </svg>
        ),
    },
    {
        value: 3,
        text: 'Left Arrow',
        icon: (
            <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 40 40"
                fill="none"
            >
                <script xmlns="" />
                <rect width="40" height="40" rx="5" fill="#DCDCDC" />
                <path
                    d="M24.1965 27.9998C23.345 28.0098 22.5378 27.6155 22.0152 26.9341C21.4925 26.2527 21.3145 25.3628 21.5341 24.5289L16.6074 21.6754C15.7561 22.4658 14.5083 22.633 13.4834 22.0942C12.4586 21.5553 11.8751 20.425 12.0226 19.2646C12.1702 18.1042 13.0174 17.1607 14.1436 16.9027C15.2697 16.6447 16.435 17.1271 17.0608 18.1104L21.5333 15.5192C21.4755 15.2976 21.4448 15.0697 21.442 14.8405C21.4307 13.506 22.3454 12.3467 23.6324 12.0641C24.9195 11.7816 26.2256 12.4533 26.7603 13.6728C27.2951 14.8924 26.9117 16.3249 25.8421 17.1035C24.7726 17.8821 23.3106 17.793 22.3408 16.8902L17.4999 19.6935C17.4951 19.9003 17.4666 20.1059 17.4149 20.306L22.3408 23.1588C23.2476 22.3154 24.597 22.1852 25.6445 22.84C26.6921 23.4948 27.1829 24.7752 26.8463 25.9749C26.5096 27.1746 25.4274 28.0016 24.1965 27.9998ZM24.1965 24.0121C23.5446 24.0121 23.016 24.5477 23.016 25.2084C23.016 25.8691 23.5446 26.4047 24.1965 26.4047C24.8485 26.4047 25.3771 25.8691 25.3771 25.2084C25.3771 24.5477 24.8485 24.0121 24.1965 24.0121ZM14.7525 18.4294C14.1005 18.4294 13.572 18.965 13.572 19.6257C13.572 20.2864 14.1005 20.822 14.7525 20.822C15.4045 20.822 15.933 20.2864 15.933 19.6257C15.933 18.965 15.4045 18.4294 14.7525 18.4294ZM24.1965 13.6442C23.5446 13.6442 23.016 14.1798 23.016 14.8405C23.016 15.5012 23.5446 16.0368 24.1965 16.0368C24.8485 16.0368 25.3771 15.5012 25.3771 14.8405C25.3771 14.1798 24.8485 13.6442 24.1965 13.6442Z"
                    fill="#636363"
                />
            </svg>
        ),
    },
    {
        value: 4,
        text: 'Right Arrow',
        icon: (
            <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 40 40"
                fill="none"
            >
                <script xmlns="" />
                <rect width="40" height="40" rx="5" fill="#DCDCDC" />
                <path
                    d="M24.1965 27.9998C23.345 28.0098 22.5378 27.6155 22.0152 26.9341C21.4925 26.2527 21.3145 25.3628 21.5341 24.5289L16.6074 21.6754C15.7561 22.4658 14.5083 22.633 13.4834 22.0942C12.4586 21.5553 11.8751 20.425 12.0226 19.2646C12.1702 18.1042 13.0174 17.1607 14.1436 16.9027C15.2697 16.6447 16.435 17.1271 17.0608 18.1104L21.5333 15.5192C21.4755 15.2976 21.4448 15.0697 21.442 14.8405C21.4307 13.506 22.3454 12.3467 23.6324 12.0641C24.9195 11.7816 26.2256 12.4533 26.7603 13.6728C27.2951 14.8924 26.9117 16.3249 25.8421 17.1035C24.7726 17.8821 23.3106 17.793 22.3408 16.8902L17.4999 19.6935C17.4951 19.9003 17.4666 20.1059 17.4149 20.306L22.3408 23.1588C23.2476 22.3154 24.597 22.1852 25.6445 22.84C26.6921 23.4948 27.1829 24.7752 26.8463 25.9749C26.5096 27.1746 25.4274 28.0016 24.1965 27.9998ZM24.1965 24.0121C23.5446 24.0121 23.016 24.5477 23.016 25.2084C23.016 25.8691 23.5446 26.4047 24.1965 26.4047C24.8485 26.4047 25.3771 25.8691 25.3771 25.2084C25.3771 24.5477 24.8485 24.0121 24.1965 24.0121ZM14.7525 18.4294C14.1005 18.4294 13.572 18.965 13.572 19.6257C13.572 20.2864 14.1005 20.822 14.7525 20.822C15.4045 20.822 15.933 20.2864 15.933 19.6257C15.933 18.965 15.4045 18.4294 14.7525 18.4294ZM24.1965 13.6442C23.5446 13.6442 23.016 14.1798 23.016 14.8405C23.016 15.5012 23.5446 16.0368 24.1965 16.0368C24.8485 16.0368 25.3771 15.5012 25.3771 14.8405C25.3771 14.1798 24.8485 13.6442 24.1965 13.6442Z"
                    fill="#636363"
                />
            </svg>
        ),
    },
];

function AddParameter(props) {
    const [selectedOption_parameter, setSelectedOption] = useState(null);
    const handleChange = e => {
        setSelectedOption(e);
    };
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);


    return (
        <div>

            <Button onClick={handleOpen} varient="outlined" style={{border:'1px solid var(--main-bg)', marginRight:'20px', marginTop:'20px', marginBottom:'20px', padding:'10px 20px'}}>{props.btnname}</Button>
            <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box  className='add-parameter-box'>
                    <div className="add-parameter">
                        <div className="add-parameter-inner">
                            <div className="add-parameter-header">
                                <div>
                                    <h3>Add Custome Param</h3>
                                </div>

                                <div className="add-parameter-close">
                                    <a onClick={handleClose}>
                                        <img src={backicon} />
                                    </a>
                                </div>

                            </div>
                            <Box>
                                
                                    <Grid sx={{ flexGrow: 1, marginBottom: '40px' , padding:'25px'}} container >
                                        <Grid item xs={12}>
                                            <Grid container justifyContent="center" flexDirection="column">
                                                <Select
                                                    placeholder="Select Integraion..."
                                                    className="integration-drop-down-input-select-dashboard"
                                                    value={selectedOption_parameter}
                                                    options={select_data_parameter}
                                                    onChange={handleChange}
                                                    getOptionLabel={e => (
                                                        <div style={{ display: 'flex', alignItems: 'center', padding: '10px' }}>
                                                            {e.icon}
                                                            <span style={{ marginLeft: 5 }}>{e.text}</span>
                                                        </div>
                                                    )}
                                                />
                                            </Grid>
                                            <Paper className='select-source-add-parameter' elevation={0} >
                                                <Typography className='list-dni-group'>Source Key :</Typography>
                                                <Card variant="text" style={{ color: 'var(--main-bg)', padding: '5px', paddingLeft: '5px', width: '100px', height: 'auto', marginRight: '10px' }}> custome_2 </Card>
                                            </Paper>
                                            <Paper className='select-source-add-parameter' elevation={0} >
                                                <Typography className='list-dni-group'>Source Key :</Typography>
                                                <Card variant="text" style={{ color: 'var(--main-bg)', padding: '5px', paddingLeft: '5px', width: '100px', height: 'auto', marginRight: '10px' }}> custome_2 </Card>
                                            </Paper>
                                        </Grid>
                                    </Grid>
                              
                            </Box>
                            <div className="add-parameter-footer">

                                <Button varient="outline" style={{ background: 'var(--main-bg)', margin: '20px', width: '126px', color: 'white', border: '1px solid white' }} onClick={handleClose}>Back</Button>
                                <Button varient="contained" style={{ background: 'white', margin: '20px', width: '126px' }}>Add</Button>
                            </div>
                        </div>
                    </div>
                </Box>
            </Modal>
        </div>
    )
}

export default AddParameter
