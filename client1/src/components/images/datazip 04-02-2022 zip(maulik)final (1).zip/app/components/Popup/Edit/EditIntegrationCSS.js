import { EditIntegrationCSS } from 'styled-components';
import './asset/EditIntegrationCSS.css';

const EditIntegrationCSSExport = EditIntegrationCSS;
export default EditIntegrationCSSExport;
