import { Button, Grid, Paper } from "@mui/material";
import Box from "@mui/material/Box";
import closeicon from '../../../images/closeicon.svg'
import * as React from "react";
import Modal from '@mui/material/Modal'
import Typography from '@mui/material/Typography'

import dustbinicon from '../../../../app/images/dustbinicon.svg'
import canclebtn from '../../../../app/images/canclebtn.svg'
import deletebtn from '../../../../app/images/deletebtnprimarycolor.svg'

import { createTheme, ThemeProvider, styled } from '@mui/material/styles';

import './asset/style.css'


const style = {
    position: 'absolute',
    top: '28%',
    left: '36%',
    background: '#fff',
    borderRadius: '5px',


}
const style1 = {
    background: 'var(--delete-color)',
    color: 'white',
    display: 'flex',
    jutifyContent: 'space-around',
    width: '59vh',
    display: 'flex',
    height: '70px',
    borderRadius: 'none',



}

export default function Delete(props) {
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    return (
        <div>
            <Button varient="outlined" onClick={this.props.handleOpen}> {props.btnname}</Button>
            <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
                
            >
                <Grid container >
                    <Box sx={style}>
                        <Paper sx={style1}>
                            <Grid container xs={12} style={{ display: 'flex', justifyContent: 'flex-start', margin: '0px' }}>
                                <h2 style={{ paddingLeft: '20px' }}>Delete</h2>
                            </Grid>
                            <Grid className="close-icon-user-profile">
                                <a onClick={handleClose}>
                                    <img src={closeicon} />
                                </a>
                            </Grid>
                        </Paper>
                        <Paper className="delete-body">
                            <Grid>
                                <img src={dustbinicon}></img>
                            </Grid>
                            <Grid>
                                <Typography variant="h4">Are you sure ?</Typography>
                            </Grid>
                            <Grid>
                                <Typography >
                                    <span>Do you really want to delete these integration?</span><br></br> <span>This process cannot be undone</span></Typography>
                            </Grid>

                            <Grid className="delete-btn-group" style={{margin:'20px'}}>
                                <a style={{cursor:'pointer'}}>
                                    <img src={canclebtn} style={{marginRight:'00px'}}></img>
                                </a>
                                <a style={{cursor:'pointer'}}>
                                <img src={deletebtn}></img>

                                </a>
                            </Grid>

                        </Paper>
                    </Box>

                </Grid>

            </Modal>
        </div>
    )
}