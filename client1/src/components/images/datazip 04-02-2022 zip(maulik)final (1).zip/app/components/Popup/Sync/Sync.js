import React, { useState } from 'react';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import Button from '@mui/material/Button';
import Editicon from '../../../../app/images/editicon.svg';
import closeicon from '../../../../app/images/closeicon.svg';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import '../Sync/asset/style.css';
import { padding } from '@mui/system';

function index(props) {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);


  return (
    <>
      <Button
        size="large"
        variant="outlined"
        className="light-blue"
        id="sync-btn"
        onClick={handleOpen}
      >
        {props.btnname}
      </Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box  className="sync-popup-box" id="sync-pop-up-box">
          <div className="sync-popup">
            <div className="sync-popup-inner">
              <div
                className="sync-popup-header"
                style={{ height: '60px !important' }}
              >
                <div className="sync-popup-close" style={{ border: 'none' }}>
                  <a onClick={handleClose}>
                    <img src={closeicon} />
                  </a>
                </div>
                <div className="sync-popup-close">
                  <a onClick={handleClose}>
                    <img src={closeicon} />
                  </a>
                </div>
              </div>
              <div>
                <h2 style={{
                  marginTop: '25px',
                  marginBottom: '0px',
                  fontWeight:'800'
                }}>{props.heading}</h2>
                <h3 style={{ color: 'rgb(80,80,80',marginTop: '0px',
                  marginBottom: '0px',fontWeight:'900'}}>{props.heading2}</h3>
              </div>
              <div className='sync-popup-body'>
                <Box >
                  <Paper className='sync-list-dni-group' >
                    <Typography className='list-dni-group'>Loging</Typography>
                    <Button variant="text" className='status-btn' style={{fontWeight:'bold'}}> Done </Button>
                  </Paper>
                  <Paper className='sync-list-dni-group' >
                    <Typography className='list-dni-group'>Getting  Numbers</Typography>
                    <Button variant="text" className='status-btn'> Done </Button>
                  </Paper>
                  <Paper className='sync-list-dni-group' >
                    <Typography className='list-dni-group'>Removing Missing Numbers</Typography>
                    <Button variant="text" className='status-btn'> Done </Button>
                  </Paper>
                  <Paper className='sync-list-dni-group' >
                    <Typography className='list-dni-group'>Adding New Numbers</Typography>
                    <Button variant="text" className='status-btn'> Done </Button>
                  </Paper>
                  <Button variant="text" style={{ margin: '10px', fontWeight:'600', fontSize:'16px', color:'var(--btn-color)' }}> Complated </Button>

                </Box>
              </div>


            </div>
          </div>
        </Box>
      </Modal>
    </>
  );
}

export default index;
