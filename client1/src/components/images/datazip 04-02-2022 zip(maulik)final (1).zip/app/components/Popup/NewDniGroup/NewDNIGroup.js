import React from 'react';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import Button from '@mui/material/Button';

import TextareaAutosize from '@mui/material/TextareaAutosize';
import { InputAdornment } from '@mui/material';
import Editicon from '../../../containers/Help&Support/img/editicon.svg';
import closeicon from '../../../images/closeicon.svg';
import './style.css';

const NewDNIGroup = () => {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  return (
    <>
      <Button size="large" variant="contained" onClick={handleOpen}>
        ADD
      </Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box className='new-dni-group-popup-main'>
          <div className="add-popup">
            <div className="add-popup-inner">
              <div className="add-popup-header">
                <div className="add-popup-close" style={{ border: 'none' }}>
                  <a onClick={handleClose}>
                    <img src={closeicon} />
                  </a>
                </div>
                <div className="add-popup-close" style={{ border: 'none' }}>
                  <a onClick={handleClose}>
                    <img src={closeicon} />
                  </a>
                </div>
              </div>
              <div>
                <h3>New DNI Group </h3>
              </div>
              <div className="add-popup-question">
                            <a className="send-btn">NEXT</a>
                          </div>
            </div>
          </div>
        </Box>
      </Modal>
    </>
  );
};

export default NewDNIGroup;
