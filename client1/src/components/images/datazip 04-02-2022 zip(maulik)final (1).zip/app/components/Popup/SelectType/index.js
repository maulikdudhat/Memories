import React, { useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import Button from '@mui/material/Button';
import Editicon from '../../../../app/images/editicon.svg';
import closeicon from '../../../../app/images/closeicon.svg';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import { InputAdornment } from '@mui/material';
// icons are imported here
import passwordicon from '../Edit/asset/img/passwordicon.svg';
import emailicon from '../Edit/asset/img/emailicon.svg';
import usericon from '../Edit/asset/img/usericon.svg';
import passworldicon from '../Edit/asset/img/passwordicon.svg';
import five9icon from '../../../../app/images/five9.svg';
import logoipsum from '../../../../app/images/logoipsum.svg';
import loginipsum1 from '../../../../app/images/logoipsum1.svg';
import loginipsum2 from '../../../../app/images/logoipsum2.svg';

//import './EditIntegration.css';

//import './EditIntegration.css';
import '../SelectType/asset/style.css';

import { margin, padding } from '@mui/system';
import axios from 'axios';
import noteContext from '../../../context/noteContext';

function index(props) {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const intitalValue = { email: '', username: '', password: '' };
  const [enterValue, setEnterValue] = useState(intitalValue);
  const [loginError, setLoginError] = useState({});
  const [errMessage, setErrMessage] = useState('');

  const url = 'http://localhost:3344/integration/addintegration';

  const style = {
    position: 'absolute',
    top: '25%',
    left: '29%',
  };
  useEffect(() => {
    if (Object.keys(loginError).length === 0) {
    }
    console.log('works');
  }, [loginError]);

  const validate = values => {
    const errors = {};

    if (!values.email) {
      errors.email = 'email is require !';
    }
    if (!values.username) {
      errors.username = 'username is require';
    }

    if (!values.password) {
      errors.password = 'password is require !';
    }

    return errors;
  };

  const img = [];
  const handlechange = e => {
    const { name, value } = e.target;
    setEnterValue({ ...enterValue, [name]: value });
    console.log(enterValue);
  };
  const handelSave = e => {
    // e.preventDefault();
    setLoginError(validate(enterValue));
    axios
      .post('http://localhost:3344/integration/addintegration', {
        user: enterValue.username,
        email: enterValue.email,
        password: enterValue.password,
      })
      .then(res => {
        console.log(res.data);
        setErrMessage(res.data);
        setOpen(false);
      })
      .catch(e => {
        const { message } = req.body;
        setErrMessage(message);
        console.log(message);
      });
  };

  return (
    <>
      {
        <img
          src={five9icon}
          onClick={handleOpen}
          style={{ cursor: 'pointer' }}
        />
      }

      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
        data={handleOpen}
      >
        <Box className="select-type-integration-main">
          <div className="select-popup">
            <div className="select-popup-inner">
              <div
                className="select-popup-header"
                style={{ height: '60px !important' }}
              >
                <div className="select-popup-close" style={{ border: 'none' }}>
                  <a onClick={handleClose}>
                    <img src={closeicon} />
                  </a>
                </div>
                <div className="select-popup-close">
                  <a onClick={handleClose}>
                    <img src={closeicon} />
                  </a>
                </div>
              </div>
              <div>
                <h2>{props.heading}</h2>
                <h3 style={{ color: 'rgb(80,80,80' }}>{props.heading2}</h3>
              </div>
              <div
                className="edit-integration-popup-body"
                style={{ justifyContent: 'unsafe !important' }}
              >
                <Box>
                  <Grid item xs={11}>
                    <TextField
                      className="email-text-field"
                      margin="normal"
                      style={{
                        border: 'none !important',
                        position: 'relative',
                        left: '32px',
                      }}
                      required
                      fullWidth
                      id="input-with-icon-textfield"
                      name="email"
                      placeholder="Five9.com"
                      onChange={handlechange}
                      value={enterValue.email}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <img src={emailicon} alt="Email Address" />
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Grid>
                  <p className="login-errors">{loginError.email}</p>
                  <Grid item xs={11}>
                    <TextField
                      className="email-text-field"
                      margin="normal"
                      style={{
                        border: 'none !important',
                        position: 'relative',
                        left: '32px',
                      }}
                      required
                      fullWidth
                      id="input-with-icon-textfield"
                      name="username"
                      placeholder="Five9"
                      onChange={handlechange}
                      value={enterValue.username}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <img src={usericon} alt="Email Address" />
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Grid>
                  <p className="login-errors">{loginError.username}</p>
                  <Grid item xs={11}>
                    <TextField
                      className="email-text-field"
                      margin="normal"
                      style={{
                        border: 'none !important',
                        position: 'relative',
                        left: '32px',
                      }}
                      required
                      fullWidth
                      id="input-with-icon-textfield"
                      name="password"
                      placeholder="password"
                      type="password"
                      onChange={handlechange}
                      value={enterValue.password}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <img src={passworldicon} alt="password" />
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Grid>
                  <p className="login-errors">{loginError.password}</p>
                  <p>{errMessage}</p>
                  <div className="save-btn-group">
                    <Button
                      variant="contained"
                      className="btn-group-btn"
                      onClick={handelSave}
                    >
                      {' '}
                      Save{' '}
                    </Button>
                  </div>
                </Box>
              </div>
            </div>
          </div>
        </Box>
      </Modal>
      {/* <EditIntegrationCSS /> */}
    </>
  );
}

export default index;
