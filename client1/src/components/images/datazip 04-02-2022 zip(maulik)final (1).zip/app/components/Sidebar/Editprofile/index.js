import * as React from "react";
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import { Grid, Paper, TextField } from "@mui/material";
import Avatar from '@mui/material/Avatar';
import closeicon from '../../../../app/images/closeicon.svg';
import { createTheme, ThemeProvider, styled } from '@mui/material/styles';
import { InputAdornment } from '@mui/material';
import savebtn from '../../../../app/images/savebtn.svg';
import editiconuserprofile from '../../../../app/images/editicon-user-profile.svg';
import editicon from '../../../../app/images/editiconcard.svg'
import edtediticoncard from '../../../../app/images/editiconcard.svg'
import editiconpensile from '../../../../app/images/editicon(pensile).svg'

import EditIcon from '@mui/icons-material/Edit';


import CardMedia from '@mui/material/CardMedia';
import Card from '@mui/material/Card';

import './assets/style.css'
import { display } from "@mui/system";


const style1 = {
    background: 'var(--main-bg)',
    color: 'white',
    display: 'flex',
    jutifyContent: 'space-around',
    width: '59vh',
    display: 'flex',
    height: '70px',
    borderRadius:'0px !important',
    boxShadow:'none',



}
const style2 = {
    height: '80% !important',
    width: '70% !important'
}

const useStyles = styled(theme => ({
    text: {
        margin: theme.spacing(0, 0, 0.5),
        
    },
    avatar: {
        verticalAlign: 'middle',
        marginRight: theme.spacing(0.5),
    },
    large: {
        width: theme.spacing(12),
        height: theme.spacing(12),
        margin: theme.spacing(2, 2, 0),
    },
    card: {
        borderRadius: 5,
        maxWidth: '500px',
        minWidth: '270px',
        height: '330px !important',
        backgroundColor: theme.palette.background.card,
    },
    cardContent: {
        padding: theme.spacing(2, 0, 0, 0),
    },
}));

export default function index(props) {
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);




    return (
        <div class="profile-model-main">
        <div >
            { (props.btnname =='edit')?
                <Button onClick={handleOpen} startIcon={(props.btnname == 'edit'? <EditIcon/> :'')} varient="outlined" className="edit-btn" style={{backgroundColor:(props.btnname == 'edit'? 'white':'none')}}>{(props.btnname == 'edit') ? props.btnname:<img src={editicon}></img> }</Button>
                :<img onClick={handleOpen}src={edtediticoncard}></img>
            }


            <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <div>
                    <Box className="userprofile-popup"  >
                        <Paper sx={style1}>
                            <Grid container xs={12} style={{ display: 'flex', justifyContent: 'flex-start', margin: '0px' }}>
                                <h2 style={{ paddingLeft: '20px' }}>User Profile</h2>
                            </Grid>
                            <Grid className="close-icon-user-profile">
                                <a onClick={handleClose}>
                                    <img src={closeicon} />

                                </a>
                            </Grid>
                        </Paper>

                        <Paper elevation={0} className="userProfile">
                            <CardMedia>
                                <Avatar
                                    alt="profile img"
                                    src="https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50?s=300"
                                    className="img-block-user-profile"
                                />
                            </CardMedia>
                        </Paper>

                        <Grid item xs={11}>
                            <Grid xs={12} >
                                <Typography variant="h5" style={{ position: 'relative', left: '30px', top: '15px', bottom: '15px', paddingBottom:'5px' }}>Name</Typography>

                                <TextField
                                    className="email-text-field"
                                    margin="normal"
                                    style={{ border: 'none !important', position: 'relative', left: '25px' }}
                                    required
                                    fullWidth
                                    id="input-with-icon-textfield"
                                    name="name"
                                    placeholder="Name"
                                    InputProps={{
                                        endAdornment: (
                                            <InputAdornment position="end">
                                                <img
                                                    src={editiconuserprofile}
                                                    alt="Name"
                                                />
                                            </InputAdornment>
                                        ),
                                    }}
                                />
                            </Grid>
                            <Grid xs={12} >
                                <Typography variant="h5" style={{ position: 'relative', left: '30px', top: '15px', bottom: '15px', paddingBottom:'5px' }}>Email</Typography>

                                <TextField
                                    className="email-text-field"
                                    margin="normal"
                                    style={{ border: 'none !important', position: 'relative', left: '25px' }}
                                    required
                                    fullWidth
                                    id="input-with-icon-textfield"
                                    name="name"
                                    placeholder="Email"
                                    InputProps={{
                                        endAdornment: (
                                            <InputAdornment position="end">
                                                <img
                                                    src={editiconuserprofile}
                                                    alt="Name"
                                                />
                                            </InputAdornment>
                                        ),
                                    }}
                                />
                            </Grid>
                            <Grid xs={12} >
                                <Typography variant="h5" style={{ position: 'relative', left: '30px', top: '15px', bottom: '15px',paddingBottom:'5px' }}>Phone</Typography>

                                <TextField
                                    className="email-text-field"
                                    margin="normal"
                                    style={{ border: 'none !important', position: 'relative', left: '25px' }}
                                    required
                                    fullWidth
                                    id="input-with-icon-textfield"
                                    name="number"
                                    type="number"
                                    placeholder="(123)456-7890"
                                    InputProps={{
                                        endAdornment: (
                                            <InputAdornment position="start">
                                                <img
                                                    src={editiconuserprofile}
                                                    alt="Name"
                                                />
                                            </InputAdornment>
                                        ),
                                    }}
                                />
                            </Grid>

                        </Grid>
                        <Paper className="user-profile-footer">
                            <a>
                                <img className="save-btn" src={savebtn} />
                            </a>
                        </Paper>


                    </Box>
                </div>


            </Modal>
        </div>
        </div>
    )
}