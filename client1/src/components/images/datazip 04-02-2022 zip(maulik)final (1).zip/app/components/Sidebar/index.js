import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import logo from '../Sidebar/assets/img/logo.png';

import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Avatar from '@mui/material/Avatar';

import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';

import Divider from '@mui/material/Divider';

import InboxIcon from '@mui/icons-material/Inbox';
import DraftsIcon from '@mui/icons-material/Drafts';
import EditIcon from '@mui/icons-material/Edit';


// mui icons import here
import HeadsetMicOutlinedIcon from '@mui/icons-material/HeadsetMicOutlined';
import SettingsOutlinedIcon from '@mui/icons-material/SettingsOutlined';
import LogoutOutlinedIcon from '@mui/icons-material/LogoutOutlined';

import { createTheme, ThemeProvider, styled } from '@mui/material/styles';

import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';

import './assets/css/style.css';
import { height } from '@mui/system';
import { Link } from 'react-router-dom';

// model resouce import here
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';

// popup import here
import Popup from '../../components/Popup/index';

import EditProfile from '../../components/Sidebar/EditProfile/index';


import TextareaAutosize from '@mui/material/TextareaAutosize';
import { InputAdornment } from '@mui/material';
import EmailAddressIcon from '../../../app/containers/LoginPage/assets/img/EmailAddressIcon.svg';
import Editicon from '../../containers/Help&Support/img/editicon.svg';
import closeicon from '../../../app/images/closeicon.svg';

// divider style
const style_divider = {
  width: '100%',
  // maxWidth: 360,
  bgcolor: 'background.paper',
};



const useStyles = styled(theme => ({
  text: {
    margin: theme.spacing(0, 0, 0.5),
    //color: theme.palette.secondary.contrastText,
  },
  avatar: {
    verticalAlign: 'middle',
    marginRight: theme.spacing(0.5),
  },
  large: {
    width: theme.spacing(12),
    height: theme.spacing(12),
    margin: theme.spacing(2, 2, 0),
  },
  card: {
    borderRadius: 15,
    maxWidth: '270px',
    minWidth: '270px',
    height: '330px',
    backgroundColor: theme.palette.background.card,
  },
  cardContent: {
    padding: theme.spacing(2, 0, 0, 0),
  },
}));

// popup style

// const style = {
//   position: 'absolute',
//   top: '25%',
//   left: '28%'
// };

function index(props) {
  const classes = useStyles();

  const [age, setAge] = React.useState('0');

  const handleChange = event => {
    setAge(event.target.value);
  };
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  return (
    <div className="sidebar">
      
        <div className="sidebarlogo">
          <img src={logo} alt="company logo" />
        </div>
        <Divider sx={style_divider} />
        <div className="sidebar-inner">
        <div>
          <FormControl className="form-drop-down-name">
            <Select
              className="name-drop-down-menu"
              value={age}
              onChange={handleChange}
              variant="outlined"
            >
              <MenuItem value={0}>Alder</MenuItem>
              <MenuItem value={1}>Alder 1</MenuItem>
              <MenuItem value={2}>Alder 2</MenuItem>
              <MenuItem value={3}>Alder 3</MenuItem>
            </Select>
          </FormControl>
        </div>



        <div className="sidebar-items ">
          <nav aria-label="main nav top-nav">
            <List>
              <Link to="/dashboard" className="menu-link">
                
                  <ListItem disablePadding>
                    <ListItemButton className={`list-item-main`}>

                      <ListItemIcon className="list-item-icon ">

                        <svg
                          width="21"
                          height="22"
                          viewBox="0 0 21 22"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M7.65722 19.7714V16.7047C7.6572 15.9246 8.29312 15.2908 9.08101 15.2856H11.9671C12.7587 15.2856 13.4005 15.9209 13.4005 16.7047V16.7047V19.7809C13.4003 20.4432 13.9343 20.9845 14.603 21H16.5271C18.4451 21 20 19.4607 20 17.5618V17.5618V8.83784C19.9898 8.09083 19.6355 7.38935 19.038 6.93303L12.4577 1.6853C11.3049 0.771566 9.6662 0.771566 8.51342 1.6853L1.96203 6.94256C1.36226 7.39702 1.00739 8.09967 1 8.84736V17.5618C1 19.4607 2.55488 21 4.47291 21H6.39696C7.08235 21 7.63797 20.4499 7.63797 19.7714V19.7714"
                            stroke-width="1.5"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                          />
                        </svg>

                      </ListItemIcon>

                      <ListItemText
                        primary="Dashboard"
                        className="list-txt-block"
                      />
                    </ListItemButton>
                  </ListItem>
               
              </Link>

              <Link to="integrations" className="menu-link">
                <ListItem disablePadding>
                  <ListItemButton className={`list-item-main `}>
                    <ListItemIcon className="list-item-icon second-icon">
                      <svg
                        width="15"
                        height="16"
                        viewBox="0 0 15 16"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path d="M12.1965 15.9998C11.345 16.0098 10.5378 15.6155 10.0152 14.9341C9.49249 14.2527 9.31449 13.3628 9.5341 12.5289L4.60745 9.67537C3.75613 10.4658 2.50826 10.633 1.48342 10.0942C0.458586 9.55528 -0.124914 8.42502 0.0226447 7.26459C0.170203 6.10415 1.01739 5.16072 2.14355 4.90272C3.26972 4.64473 4.43498 5.12712 5.06076 6.11039L9.53332 3.5192C9.47545 3.29764 9.44479 3.06968 9.44202 2.8405C9.43075 1.506 10.3454 0.346726 11.6324 0.0641435C12.9195 -0.218439 14.2256 0.453277 14.7603 1.67284C15.2951 2.89241 14.9117 4.32489 13.8421 5.10351C12.7726 5.88213 11.3106 5.79304 10.3408 4.89016L5.49991 7.6935C5.49512 7.90032 5.4666 8.10587 5.41492 8.306L10.3408 11.1588C11.2476 10.3154 12.597 10.1852 13.6445 10.84C14.6921 11.4948 15.1829 12.7752 14.8463 13.9749C14.5096 15.1746 13.4274 16.0016 12.1965 15.9998ZM12.1965 12.0121C11.5446 12.0121 11.016 12.5477 11.016 13.2084C11.016 13.8691 11.5446 14.4047 12.1965 14.4047C12.8485 14.4047 13.3771 13.8691 13.3771 13.2084C13.3771 12.5477 12.8485 12.0121 12.1965 12.0121ZM2.75248 6.42941C2.1005 6.42941 1.57197 6.96501 1.57197 7.62571C1.57197 8.28641 2.1005 8.82201 2.75248 8.82201C3.40445 8.82201 3.93299 8.28641 3.93299 7.62571C3.93299 6.96501 3.40445 6.42941 2.75248 6.42941ZM12.1965 1.6442C11.5446 1.6442 11.016 2.1798 11.016 2.8405C11.016 3.5012 11.5446 4.0368 12.1965 4.0368C12.8485 4.0368 13.3771 3.5012 13.3771 2.8405C13.3771 2.1798 12.8485 1.6442 12.1965 1.6442Z" />
                      </svg>
                    </ListItemIcon>
                    <ListItemText
                      primary="Integrations"
                      className="list-txt-block"
                    />
                  </ListItemButton>
                </ListItem>
              </Link>

              <Link to="/numbers" className="menu-link">
                <ListItem disablePadding>
                  <ListItemButton className={`list-item-main`}>
                    <ListItemIcon className="list-item-icon second-icon">
                      <svg
                        width="18"
                        height="16"
                        viewBox="0 0 18 16"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path d="M18 16H15V6H18V16ZM13 16H10V3H13V16ZM8 16H5V0H8V16ZM3 16H0V8H3V16Z" />
                      </svg>
                    </ListItemIcon>
                    <ListItemText primary="Numbers" className="list-txt-block" />
                  </ListItemButton>
                </ListItem>
              </Link>
            </List>
          </nav>

          <nav
            className="nav bottom-nav"
            style={{
              marginBottom: '20px',
            }}
          >
            <Card
              variant="outlined"
              //className={classes.card}
              className="card-item-block"
            // style={{
            //   display: 'block',
            //   padding: '10px 15px',
            //   margin: '30px 20px',
            //   border: '1px solid rgba(255,255,255,0.6)',
            // }}
            >
              <CardMedia align="center">
                <Avatar
                  alt="Remy Sharp"
                  src="https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50?s=300"
                  className={classes.large}
                  className="img-block"
                />
              </CardMedia>
              <CardContent
                className={classes.cardContent}
                className="card-item-inner"
              >
                <Typography
                  className={classes.text}
                  className="heading-text"
                  color="textSecondary"
                  variant="h6"
                  align="center"
                >
                  John Doe
                </Typography>
                <Typography
                  className={classes.text}
                  className="subheading-txt"
                  color="textSecondary"
                  variant="subtitle1"
                  align="center"
                >
                  Lorem Ipsum
                </Typography>

                <EditProfile btnname="edit" />
              </CardContent>
            </Card>
            <div className="button_group">
              <Link to="/settings" className="menu-link">
                <Button
                  variant="outlined"
                  style={{
                    color: '#fff',
                    border: '1px solid rgba(255,255,255,0.7',
                    objectFit: 'contain',
                    margin: '5px 18px',
                    width: '200px',
                    paddingRight: '95px',
                    textTransform: 'none',
                  }}
                  startIcon={
                    <div className="button_icon_bg">
                      <SettingsOutlinedIcon />
                    </div>
                  }
                >
                  Settings
                </Button>
              </Link>

              <Button
                variant="outlined"
                onClick={handleOpen}
                style={{
                  color: '#fff',
                  border: '1px solid rgba(255,255,255,0.7',
                  objectFit: 'contain',
                  margin: '5px 18px',
                  width: '200px',
                  paddingRight: '52px',
                  textTransform: 'none',
                }}
                startIcon={
                  <div className="button_icon_bg">
                    <HeadsetMicOutlinedIcon />
                  </div>
                }
              >
                Help / Support
              </Button>
              <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
              >
                <Box className='help-support-popup'>
                  <div className="pop-up">
                    <div className="popup-inner">
                      <div className="popup-header">
                        <div>
                          <h3>Help/Support</h3>
                        </div>
                        <div className="popup-close" style={{ border: 'none' }}>
                          <a onClick={handleClose}>
                            <img src={closeicon} />
                          </a>
                        </div>
                      </div>
                      <div className="popup-question">
                        <div className="popup-question-inner">
                          <div>
                            <TextareaAutosize
                              maxRows={5}
                              aria-label="maximum height"
                              placeholder="Question"
                              className="popup-textarea"
                              style={{
                                width: 750,
                                height: 190,
                                paddingInline: 60,
                                paddingTop: 15,
                                boxShadow: 'none',
                                border: '1px solid #00000017'
                              }}
                            />
                          </div>
                          <div>
                            <InputAdornment position="start">
                              <img
                                src={Editicon}
                                className="question-input"
                                alt="icon"
                              />
                            </InputAdornment>
                          </div>
                        </div>

                        <a className="send-btn">SEND</a>
                      </div>
                    </div>
                  </div>
                </Box>
              </Modal>

              <Link to="/" className="menu-link">
                <Button
                  variant="outlined"
                  style={{
                    color: '#fff',
                    border: '1px solid rgba(255,255,255,0.7',
                    objectFit: 'contain',
                    margin: '5px 18px',
                    width: '200px',
                    paddingRight: '100px',
                    textTransform: 'none',
                  }}
                  startIcon={
                    <div className="button_icon_bg">
                      <LogoutOutlinedIcon />
                    </div>
                  }
                >
                  Logout
                </Button>
              </Link>
            </div>
          </nav>
        </div>
      </div>
    </div>
  );
}

export default index;
