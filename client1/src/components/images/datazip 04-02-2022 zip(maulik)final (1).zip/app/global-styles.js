import { createGlobalStyle } from 'styled-components';
import './global-assets/css/style.css';

const GlobalStyle = createGlobalStyle``;
export default GlobalStyle;
