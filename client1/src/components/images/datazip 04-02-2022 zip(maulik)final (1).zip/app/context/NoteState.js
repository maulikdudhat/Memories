import NoteContext from './noteContext';
import { Provider } from 'react';
import * as React from 'react';

const NoteState = props => {
  const state = {
    isLogin: false,
  };
  return (
    <NoteContext.Provider value={state}>{props.children}</NoteContext.Provider>
  );
};

export default NoteState;
