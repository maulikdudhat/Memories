import axios from "axios";
// require('dotenv').config();


export const login = async (model) => {


    const url = `${process.env.REACT_APP_BASE_URL}/auth/register`;

    return axios.post(url, model).then(res => {
        return res.data;
    })
}

