import React from 'react';
import { TextField, Button, Typography, Paper } from '@mui/material';

const Form = () => {
    return (
        <Paper className={paper}>
            <form autoComplete="off" noValidate clasName="form" onSubmit={handleSubmit}>

            </form>
        </Paper>
    )
};

export default Form;
