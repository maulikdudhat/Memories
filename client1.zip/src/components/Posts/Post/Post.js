import React from 'react';

const Post = () => {
    return <div><h4>post</h4></div>;
};

export default Post;
